-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : rdszij7jqr3qnmi.mysql.rds.aliyuncs.com
-- Port     : 3306
-- Database : runmoney
-- 
-- Part : #1
-- Date : 2015-03-30 20:21:19
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `rm_action`
-- -----------------------------
DROP TABLE IF EXISTS `rm_action`;
CREATE TABLE `rm_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text COMMENT '行为规则',
  `log` text COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `rm_action`
-- -----------------------------
INSERT INTO `rm_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `rm_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `rm_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '1', '1383285646');
INSERT INTO `rm_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '0', '1386139726');
INSERT INTO `rm_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `rm_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `rm_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `rm_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `rm_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `rm_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `rm_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');

-- -----------------------------
-- Table structure for `rm_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `rm_action_log`;
CREATE TABLE `rm_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `rm_action_log`
-- -----------------------------
INSERT INTO `rm_action_log` VALUES ('1', '1', '1', '3732974883', 'member', '1', 'ninstein在2014-12-26 23:13登录了后台', '1', '1419606832');
INSERT INTO `rm_action_log` VALUES ('2', '1', '2', '3732974641', 'member', '2', '36020在2014-12-26 23:17登录了后台', '1', '1419607037');
INSERT INTO `rm_action_log` VALUES ('3', '1', '1', '3732974604', 'member', '1', 'ninstein在2014-12-26 23:34登录了后台', '1', '1419608041');
INSERT INTO `rm_action_log` VALUES ('4', '1', '1', '1941307911', 'member', '1', 'ninstein在2014-12-30 14:16登录了后台', '1', '1419920162');
INSERT INTO `rm_action_log` VALUES ('5', '1', '1', '3732975735', 'member', '1', 'ninstein在2014-12-31 00:34登录了后台', '1', '1419957245');
INSERT INTO `rm_action_log` VALUES ('6', '1', '1', '1919964149', 'member', '1', 'ninstein在2015-01-04 11:18登录了后台', '1', '1420341483');
INSERT INTO `rm_action_log` VALUES ('7', '1', '1', '1919964149', 'member', '1', 'ninstein在2015-01-04 11:20登录了后台', '1', '1420341648');
INSERT INTO `rm_action_log` VALUES ('8', '1', '1', '1928897289', 'member', '1', 'ninstein在2015-01-18 14:00登录了后台', '1', '1421560857');
INSERT INTO `rm_action_log` VALUES ('9', '1', '1', '1919964149', 'member', '1', 'ninstein在2015-03-02 16:48登录了后台', '1', '1425286093');
INSERT INTO `rm_action_log` VALUES ('10', '1', '6', '1919964149', 'member', '6', 'dysecho在2015-03-02 16:59登录了后台', '1', '1425286760');
INSERT INTO `rm_action_log` VALUES ('11', '1', '1', '1919964149', 'member', '1', 'ninstein在2015-03-02 17:19登录了后台', '1', '1425287976');
INSERT INTO `rm_action_log` VALUES ('12', '1', '5', '3659428867', 'member', '5', 'dys在2015-03-02 17:41登录了后台', '1', '1425289298');
INSERT INTO `rm_action_log` VALUES ('13', '1', '6', '3659428867', 'member', '6', 'dysecho在2015-03-02 17:59登录了后台', '1', '1425290385');
INSERT INTO `rm_action_log` VALUES ('14', '1', '6', '3659428867', 'member', '6', 'dysecho在2015-03-02 18:02登录了后台', '1', '1425290524');
INSERT INTO `rm_action_log` VALUES ('15', '1', '1', '1919964149', 'member', '1', 'ninstein在2015-03-02 18:05登录了后台', '1', '1425290719');
INSERT INTO `rm_action_log` VALUES ('16', '1', '6', '1993302842', 'member', '6', 'dysecho在2015-03-02 21:43登录了后台', '1', '1425303786');
INSERT INTO `rm_action_log` VALUES ('17', '1', '6', '1993302842', 'member', '6', 'dysecho在2015-03-02 21:44登录了后台', '1', '1425303849');
INSERT INTO `rm_action_log` VALUES ('18', '1', '6', '1993302842', 'member', '6', 'dysecho在2015-03-02 22:21登录了后台', '1', '1425306060');
INSERT INTO `rm_action_log` VALUES ('19', '1', '6', '1993302842', 'member', '6', 'dysecho在2015-03-02 22:22登录了后台', '1', '1425306127');
INSERT INTO `rm_action_log` VALUES ('20', '1', '6', '3659428868', 'member', '6', 'dysecho在2015-03-03 09:57登录了后台', '1', '1425347872');
INSERT INTO `rm_action_log` VALUES ('21', '1', '6', '3659428868', 'member', '6', 'dysecho在2015-03-03 12:05登录了后台', '1', '1425355516');
INSERT INTO `rm_action_log` VALUES ('22', '1', '6', '3659428871', 'member', '6', 'dysecho在2015-03-03 13:43登录了后台', '1', '1425361391');
INSERT INTO `rm_action_log` VALUES ('23', '1', '1', '1941307911', 'member', '1', 'ninstein在2015-03-03 17:40登录了后台', '1', '1425375636');
INSERT INTO `rm_action_log` VALUES ('24', '1', '6', '1993302842', 'member', '6', 'dysecho在2015-03-03 20:50登录了后台', '1', '1425387022');
INSERT INTO `rm_action_log` VALUES ('25', '1', '6', '1993302842', 'member', '6', 'dysecho在2015-03-03 22:56登录了后台', '1', '1425394584');
INSERT INTO `rm_action_log` VALUES ('26', '1', '6', '1993302842', 'member', '6', 'dysecho在2015-03-04 08:37登录了后台', '1', '1425429458');
INSERT INTO `rm_action_log` VALUES ('27', '1', '5', '1993302842', 'member', '5', 'dys在2015-03-04 08:49登录了后台', '1', '1425430161');
INSERT INTO `rm_action_log` VALUES ('28', '1', '6', '1993302842', 'member', '6', 'dysecho在2015-03-04 23:12登录了后台', '1', '1425481927');
INSERT INTO `rm_action_log` VALUES ('29', '1', '6', '1993302842', 'member', '6', 'dysecho在2015-03-04 23:15登录了后台', '1', '1425482122');
INSERT INTO `rm_action_log` VALUES ('30', '1', '5', '1993302842', 'member', '5', 'dys在2015-03-04 23:24登录了后台', '1', '1425482650');
INSERT INTO `rm_action_log` VALUES ('31', '1', '5', '1993302842', 'member', '5', 'dys在2015-03-05 06:49登录了后台', '1', '1425509383');
INSERT INTO `rm_action_log` VALUES ('32', '1', '1', '1941307911', 'member', '1', 'ninstein在2015-03-05 14:41登录了后台', '1', '1425537717');
INSERT INTO `rm_action_log` VALUES ('33', '1', '1', '1941307911', 'member', '1', 'ninstein在2015-03-05 14:42登录了后台', '1', '1425537742');
INSERT INTO `rm_action_log` VALUES ('34', '1', '5', '1993302842', 'member', '5', 'dys在2015-03-05 22:33登录了后台', '1', '1425566015');
INSERT INTO `rm_action_log` VALUES ('35', '1', '1', '3732974856', 'member', '1', 'ninstein在2015-03-05 23:53登录了后台', '1', '1425570786');
INSERT INTO `rm_action_log` VALUES ('36', '1', '1', '1941307911', 'member', '1', 'ninstein在2015-03-06 11:58登录了后台', '1', '1425614306');
INSERT INTO `rm_action_log` VALUES ('37', '1', '1', '1941307911', 'member', '1', 'ninstein在2015-03-06 17:49登录了后台', '1', '1425635344');
INSERT INTO `rm_action_log` VALUES ('38', '1', '5', '1993302842', 'member', '5', 'dys在2015-03-06 20:48登录了后台', '1', '1425646080');
INSERT INTO `rm_action_log` VALUES ('39', '1', '1', '3732976537', 'member', '1', 'ninstein在2015-03-07 22:03登录了后台', '1', '1425737020');
INSERT INTO `rm_action_log` VALUES ('40', '1', '5', '1993302842', 'member', '5', 'dys在2015-03-09 21:06登录了后台', '1', '1425906391');
INSERT INTO `rm_action_log` VALUES ('41', '1', '1', '1928974462', 'member', '1', 'ninstein在2015-03-10 00:28登录了后台', '1', '1425918533');
INSERT INTO `rm_action_log` VALUES ('42', '1', '1', '1928974462', 'member', '1', 'ninstein在2015-03-10 22:46登录了后台', '1', '1425998772');
INSERT INTO `rm_action_log` VALUES ('43', '1', '1', '1928974462', 'member', '1', 'ninstein在2015-03-10 23:01登录了后台', '1', '1425999705');
INSERT INTO `rm_action_log` VALUES ('44', '1', '6', '1993302842', 'member', '6', 'dysecho在2015-03-10 23:10登录了后台', '1', '1426000211');
INSERT INTO `rm_action_log` VALUES ('45', '1', '5', '1993302842', 'member', '5', 'dys在2015-03-10 23:11登录了后台', '1', '1426000304');
INSERT INTO `rm_action_log` VALUES ('46', '1', '1', '3732975251', 'member', '1', 'ninstein在2015-03-11 01:06登录了后台', '1', '1426007161');
INSERT INTO `rm_action_log` VALUES ('47', '1', '1', '3732975412', 'member', '1', 'ninstein在2015-03-11 23:18登录了后台', '1', '1426087102');
INSERT INTO `rm_action_log` VALUES ('48', '1', '1', '1928975332', 'member', '1', 'ninstein在2015-03-12 00:27登录了后台', '1', '1426091228');
INSERT INTO `rm_action_log` VALUES ('49', '1', '5', '3659428868', 'member', '5', 'dys在2015-03-12 09:54登录了后台', '1', '1426125257');
INSERT INTO `rm_action_log` VALUES ('50', '1', '6', '3659428868', 'member', '6', 'dysecho在2015-03-12 09:55登录了后台', '1', '1426125308');
INSERT INTO `rm_action_log` VALUES ('51', '1', '1', '1919964149', 'member', '1', 'ninstein在2015-03-12 15:33登录了后台', '1', '1426145589');
INSERT INTO `rm_action_log` VALUES ('52', '1', '5', '1993302842', 'member', '5', 'dys在2015-03-12 21:24登录了后台', '1', '1426166649');
INSERT INTO `rm_action_log` VALUES ('53', '1', '5', '1993302842', 'member', '5', 'dys在2015-03-12 21:40登录了后台', '1', '1426167632');
INSERT INTO `rm_action_log` VALUES ('54', '1', '5', '1993302842', 'member', '5', 'dys在2015-03-12 21:40登录了后台', '1', '1426167650');
INSERT INTO `rm_action_log` VALUES ('55', '1', '1', '1928977780', 'member', '1', 'ninstein在2015-03-15 10:43登录了后台', '1', '1426387430');
INSERT INTO `rm_action_log` VALUES ('56', '1', '1', '1928977780', 'member', '1', 'ninstein在2015-03-15 15:58登录了后台', '1', '1426406285');
INSERT INTO `rm_action_log` VALUES ('57', '1', '7', '1928976873', 'member', '7', 'ninstein1在2015-03-15 16:28登录了后台', '1', '1426408101');
INSERT INTO `rm_action_log` VALUES ('58', '1', '1', '3732975250', 'member', '1', 'ninstein在2015-03-15 21:41登录了后台', '1', '1426426871');
INSERT INTO `rm_action_log` VALUES ('59', '1', '8', '1697110737', 'member', '8', 'bparadise在2015-03-15 23:23登录了后台', '1', '1426432998');
INSERT INTO `rm_action_log` VALUES ('60', '1', '8', '1697110737', 'member', '8', 'bparadise在2015-03-15 23:30登录了后台', '1', '1426433449');
INSERT INTO `rm_action_log` VALUES ('61', '1', '8', '3059547418', 'member', '8', 'bparadise在2015-03-16 18:42登录了后台', '1', '1426502553');
INSERT INTO `rm_action_log` VALUES ('62', '1', '5', '1993301187', 'member', '5', 'dys在2015-03-16 21:21登录了后台', '1', '1426512099');
INSERT INTO `rm_action_log` VALUES ('63', '1', '1', '3732974806', 'member', '1', 'ninstein在2015-03-16 23:07登录了后台', '1', '1426518443');
INSERT INTO `rm_action_log` VALUES ('64', '1', '5', '3659428868', 'member', '5', 'dys在2015-03-17 09:47登录了后台', '1', '1426556824');
INSERT INTO `rm_action_log` VALUES ('65', '1', '1', '3732976297', 'member', '1', 'ninstein在2015-03-17 22:18登录了后台', '1', '1426601918');
INSERT INTO `rm_action_log` VALUES ('66', '1', '1', '1928979522', 'member', '1', 'ninstein在2015-03-30 20:20登录了后台', '1', '1427718059');

-- -----------------------------
-- Table structure for `rm_addons`
-- -----------------------------
DROP TABLE IF EXISTS `rm_addons`;
CREATE TABLE `rm_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `rm_addons`
-- -----------------------------
INSERT INTO `rm_addons` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0');
INSERT INTO `rm_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `rm_addons` VALUES ('3', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512022', '0');
INSERT INTO `rm_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `rm_addons` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0');
INSERT INTO `rm_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '1', 'null', 'thinkphp', '0.1', '1379842319', '1');
INSERT INTO `rm_addons` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"\",\"comment_short_name_duoshuo\":\"\",\"comment_data_list_duoshuo\":\"\"}', 'thinkphp', '0.1', '1380273962', '0');

-- -----------------------------
-- Table structure for `rm_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `rm_attachment`;
CREATE TABLE `rm_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `rm_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `rm_attribute`;
CREATE TABLE `rm_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL DEFAULT '',
  `validate_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `error_info` varchar(100) NOT NULL DEFAULT '',
  `validate_type` varchar(25) NOT NULL DEFAULT '',
  `auto_rule` varchar(100) NOT NULL DEFAULT '',
  `auto_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `auto_type` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `rm_attribute`
-- -----------------------------
INSERT INTO `rm_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重复', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('5', 'description', '描述', 'char(140) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1383894927', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '[DOCUMENT_POSITION]', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可见\r\n1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `rm_attribute` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `rm_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `rm_attribute` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `rm_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `rm_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');

-- -----------------------------
-- Table structure for `rm_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `rm_auth_extend`;
CREATE TABLE `rm_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `rm_auth_extend`
-- -----------------------------
INSERT INTO `rm_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `rm_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `rm_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `rm_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `rm_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `rm_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `rm_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `rm_auth_extend` VALUES ('1', '37', '1');
INSERT INTO `rm_auth_extend` VALUES ('3', '1', '1');
INSERT INTO `rm_auth_extend` VALUES ('3', '2', '1');

-- -----------------------------
-- Table structure for `rm_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `rm_auth_group`;
CREATE TABLE `rm_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `rm_auth_group`
-- -----------------------------
INSERT INTO `rm_auth_group` VALUES ('1', 'admin', '1', '默认用户组', '', '1', '1,2,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,96,97,100,102,103,105,106');
INSERT INTO `rm_auth_group` VALUES ('2', 'admin', '1', '测试用户', '测试用户', '1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195');
INSERT INTO `rm_auth_group` VALUES ('3', 'admin', '1', '普通管理员组', '', '1', '1,2,3,4,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,100,102,103,107,108,109,110,195,205,206,207,208,209,210,211,212,213,214,215,216,217,218');

-- -----------------------------
-- Table structure for `rm_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `rm_auth_group_access`;
CREATE TABLE `rm_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `rm_auth_group_access`
-- -----------------------------
INSERT INTO `rm_auth_group_access` VALUES ('2', '3');
INSERT INTO `rm_auth_group_access` VALUES ('3', '3');
INSERT INTO `rm_auth_group_access` VALUES ('4', '3');

-- -----------------------------
-- Table structure for `rm_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `rm_auth_rule`;
CREATE TABLE `rm_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=219 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `rm_auth_rule`
-- -----------------------------
INSERT INTO `rm_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/index', '内容', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('17', 'admin', '1', 'Admin/Article/examine', '审核列表', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户信息', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `rm_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('217', 'admin', '1', 'Admin/article/index', '文档列表', '1', '');
INSERT INTO `rm_auth_rule` VALUES ('218', 'admin', '1', 'Admin/think/lists', '数据列表', '1', '');

-- -----------------------------
-- Table structure for `rm_cart`
-- -----------------------------
DROP TABLE IF EXISTS `rm_cart`;
CREATE TABLE `rm_cart` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `topic_id` int(11) unsigned NOT NULL COMMENT '主题ID',
  `author_id` int(11) unsigned NOT NULL COMMENT '作者ID',
  `author_nick` char(50) NOT NULL COMMENT '作者昵称',
  `title` char(100) NOT NULL COMMENT '标题',
  `thumb` char(200) NOT NULL COMMENT '缩略图',
  `gold_price` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '金币价',
  `user_id` int(11) unsigned NOT NULL COMMENT '用户ID',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `add_time` int(11) unsigned NOT NULL COMMENT '加入时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `rm_cart`
-- -----------------------------
INSERT INTO `rm_cart` VALUES ('7', '5', '1', 'ninstein', '测试主题2', '/Uploads/Picture/150303/54f598466b6f7.jpg', '0', '1', '0', '1426519620');
INSERT INTO `rm_cart` VALUES ('2', '8', '5', 'dys', '测试主题5', '/Uploads/Picture/150303/54f598466b6f7.jpg', '0', '5', '0', '1426168048');
INSERT INTO `rm_cart` VALUES ('3', '3', '1', 'ninstein', 'fdfdsfs', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', '0', '7', '0', '1426408118');
INSERT INTO `rm_cart` VALUES ('4', '3', '1', 'ninstein', 'fdfdsfs', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', '0', '8', '0', '1426433101');
INSERT INTO `rm_cart` VALUES ('9', '3', '1', 'ninstein', 'fdfdsfs', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', '0', '1', '0', '1426603934');

-- -----------------------------
-- Table structure for `rm_category`
-- -----------------------------
DROP TABLE IF EXISTS `rm_category`;
CREATE TABLE `rm_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL DEFAULT '' COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL DEFAULT '' COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '列表绑定模型',
  `model_sub` varchar(100) NOT NULL DEFAULT '' COMMENT '子文档绑定模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  `groups` varchar(255) NOT NULL DEFAULT '' COMMENT '分组定义',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `rm_category`
-- -----------------------------
INSERT INTO `rm_category` VALUES ('1', 'blog', '博客', '0', '0', '10', '', '', '', '', '', '', '', '2,3', '2', '2,1', '0', '0', '1', '0', '0', '1', '', '1379474947', '1382701539', '1', '0', '');
INSERT INTO `rm_category` VALUES ('2', 'default_blog', '默认分类', '1', '1', '10', '', '', '', '', '', '', '', '2,3', '2', '2,1,3', '0', '1', '1', '0', '1', '1', '', '1379475028', '1386839751', '1', '0', '');

-- -----------------------------
-- Table structure for `rm_channel`
-- -----------------------------
DROP TABLE IF EXISTS `rm_channel`;
CREATE TABLE `rm_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `rm_channel`
-- -----------------------------
INSERT INTO `rm_channel` VALUES ('1', '0', '首页', 'Index/index', '1', '1379475111', '1379923177', '1', '0');
INSERT INTO `rm_channel` VALUES ('2', '0', '博客', 'Article/index?category=blog', '2', '1379475131', '1379483713', '1', '0');
INSERT INTO `rm_channel` VALUES ('3', '0', '官网', 'http://www.onethink.cn', '3', '1379475154', '1387163458', '0', '0');

-- -----------------------------
-- Table structure for `rm_codes`
-- -----------------------------
DROP TABLE IF EXISTS `rm_codes`;
CREATE TABLE `rm_codes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `code` char(12) NOT NULL COMMENT '代码',
  `name` char(40) NOT NULL COMMENT '名称',
  `name_py` char(40) NOT NULL COMMENT '名称拼音',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1681 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `rm_codes`
-- -----------------------------
INSERT INTO `rm_codes` VALUES ('1', '000001', '平安银行', 'payx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('2', '000002', '万科A', 'wkA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('3', '000004', '国农科技', 'gnkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('4', '000005', '世纪星源', 'sjxy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('5', '000006', '深振业A', 'szyA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('6', '000007', '零七股份', 'lqgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('7', '000008', '宝利来', 'bll', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('8', '000009', '中国宝安', 'zgba', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('9', '000010', '深华新', 'shx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('10', '000011', '深物业A', 'swyA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('11', '000012', '南玻A', 'nbA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('12', '000014', '沙河股份', 'shgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('13', '000016', '深康佳A', 'skjA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('14', '000017', '深中华A', 'szhA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('15', '000018', '中冠A', 'zgA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('16', '000019', '深深宝A', 'ssbA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('17', '000020', '深华发A', 'shfA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('18', '000021', '深科技', 'skj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('19', '000022', '深赤湾A', 'scwA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('20', '000023', '深天地A', 'stdA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('21', '000024', '招商地产', 'zsdc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('22', '000025', '特力A', 'tlA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('23', '000026', '飞亚达A', 'fydA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('24', '000027', '深圳能源', 'szny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('25', '000028', '国药一致', 'gyyz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('26', '000029', '深深房A', 'ssfA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('27', '000030', '富奥股份', 'fagf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('28', '000031', '中粮地产', 'zldc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('29', '000032', '深桑达A', 'ssdA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('30', '000033', '*ST新都', '*STxd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('31', '000034', '深信泰丰', 'sxtf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('32', '000035', '中国天楹', 'zgty', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('33', '000036', '华联控股', 'hlkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('34', '000037', '深南电A', 'sndA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('35', '000038', '深大通', 'sdt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('36', '000039', '中集集团', 'zjjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('37', '000040', '宝安地产', 'badc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('38', '000042', '中洲控股', 'zzkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('39', '000043', '中航地产', 'zhdc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('40', '000045', '深纺织A', 'sfzA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('41', '000046', '泛海控股', 'fhkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('42', '000048', '康达尔', 'kde', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('43', '000049', '德赛电池', 'dsdc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('44', '000050', '深天马A', 'stmA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('45', '000055', '方大集团', 'fdjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('46', '000056', '深国商', 'sgs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('47', '000058', '深赛格', 'ssg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('48', '000059', '华锦股份', 'hjgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('49', '000060', '中金岭南', 'zjln', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('50', '000061', '农产品', 'ncp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('51', '000062', '深圳华强', 'szhq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('52', '000063', '中兴通讯', 'zxtx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('53', '000065', '北方国际', 'bfgj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('54', '000066', '长城电脑', 'ccdn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('55', '000068', '华控赛格', 'hksg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('56', '000069', '华侨城A', 'hqcA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('57', '000070', '特发信息', 'tfxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('58', '000078', '海王生物', 'hwsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('59', '000088', '盐田港', 'ytg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('60', '000089', '深圳机场', 's圳jc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('61', '000090', '天健集团', 'tjjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('62', '000096', '广聚能源', 'gjny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('63', '000099', '中信海直', 'zxhz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('64', '000100', 'TCL集团', 'TCLjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('65', '000150', '宜华健康', 'yhjk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('66', '000151', '中成股份', 'zcgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('67', '000153', '丰原药业', 'fyyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('68', '000155', '川化股份', 'chgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('69', '000156', '华数传媒', 'hscm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('70', '000157', '中联重科', 'zlzk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('71', '000158', '常山股份', 'csgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('72', '000159', '国际实业', 'gjsy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('73', '000166', '申万宏源', 'swhy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('74', '000301', '东方市场', 'dfsc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('75', '000333', '美的集团', 'mdjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('76', '000338', '潍柴动力', 'wcdl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('77', '000400', '许继电气', 'xjdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('78', '000401', '冀东水泥', 'jdsn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('79', '000402', '金融街', 'jrj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('80', '000403', 'ST生化', 'STsh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('81', '000404', '华意压缩', 'hyys', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('82', '000407', '胜利股份', 'slgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('83', '000408', '金谷源', 'jgy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('84', '000409', '山东地矿', 'sddk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('85', '000410', '沈阳机床', 'syjc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('86', '000411', '英特集团', 'ytjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('87', '000413', '东旭光电', 'dxgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('88', '000415', '渤海租赁', 'bhzl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('89', '000416', '民生控股', 'mskg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('90', '000417', '合肥百货', 'hfbh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('91', '000418', '小天鹅A', 'xteA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('92', '000419', '通程控股', 'tckg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('93', '000420', '吉林化纤', 'jlhx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('94', '000421', '南京中北', 'njzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('95', '000422', '湖北宜化', 'hbyh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('96', '000423', '东阿阿胶', 'daaj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('97', '000425', '徐工机械', 'xgjx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('98', '000426', '兴业矿业', 'xyky', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('99', '000428', '华天酒店', 'htjd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('100', '000429', '粤高速A', 'ygsA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('101', '000430', '张家界', 'zjj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('102', '000488', '晨鸣纸业', 'cmzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('103', '000498', '山东路桥', 'sdlq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('104', '000501', '鄂武商A', 'ewsA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('105', '000502', '绿景控股', 'ljkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('106', '000503', '海虹控股', 'hhkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('107', '000504', '*ST传媒', '*STcm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('108', '000505', '珠江控股', 'zjkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('109', '000506', '中润资源', 'zrzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('110', '000507', '珠海港', 'zhg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('111', '000509', '华塑控股', 'hskg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('112', '000510', '金路集团', 'jljt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('113', '000511', '烯碳新材', 'xtxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('114', '000513', '丽珠集团', 'lzjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('115', '000514', '渝开发', 'ykf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('116', '000516', '国际医学', 'gjyx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('117', '000517', '荣安地产', 'radc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('118', '000518', '四环生物', 'shsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('119', '000519', '江南红箭', 'jnhj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('120', '000520', '*ST凤凰', '*STfh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('121', '000521', '美菱电器', 'mldq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('122', '000523', '广州浪奇', 'gzlq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('123', '000524', '东方宾馆', 'dfbg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('124', '000525', '红太阳', 'hty', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('125', '000526', '银润投资', 'yrtz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('126', '000528', '柳工', 'lg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('127', '000529', '广弘控股', 'ghkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('128', '000530', '大冷股份', 'dlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('129', '000531', '穗恒运A', 'shyA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('130', '000532', '力合股份', 'lhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('131', '000533', '万家乐', 'wjl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('132', '000534', '万泽股份', 'wzgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('133', '000536', '华映科技', 'hykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('134', '000537', '广宇发展', 'gyfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('135', '000538', '云南白药', 'ynby', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('136', '000539', '粤电力A', 'ydlA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('137', '000540', '中天城投', 'ztct', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('138', '000541', '佛山照明', 'fszm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('139', '000543', '皖能电力', 'wndl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('140', '000544', '中原环保', 'zyhb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('141', '000545', '金浦钛业', 'jpty', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('142', '000546', '金圆股份', 'jygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('143', '000547', '闽福发A', 'mffA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('144', '000548', '湖南投资', 'hntz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('145', '000550', '江铃汽车', 'jlqc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('146', '000551', '创元科技', 'cykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('147', '000552', '靖远煤电', 'jymd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('148', '000553', '沙隆达A', 'sldA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('149', '000554', '泰山石油', 'tssy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('150', '000555', '神州信息', 'szxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('151', '000557', '*ST广夏', '*STgx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('152', '000558', '莱茵置业', 'lyzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('153', '000559', '万向钱潮', 'wxqc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('154', '000560', '昆百大A', 'kbdA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('155', '000561', '烽火电子', 'fhdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('156', '000563', '陕国投A', 'sgtA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('157', '000564', '西安民生', 'xams', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('158', '000565', '渝三峡A', 'ysxA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('159', '000566', '海南海药', 'hnhy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('160', '000567', '海德股份', 'hdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('161', '000568', '泸州老窖', '泸zlj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('162', '000570', '苏常柴A', 'sccA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('163', '000571', '新大洲A', 'xdzA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('164', '000572', '海马汽车', 'hmqc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('165', '000573', '粤宏远A', 'yhyA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('166', '000576', '广东甘化', 'gdgh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('167', '000581', '威孚高科', 'wfgk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('168', '000582', '北部湾港', 'bbwg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('169', '000584', '友利控股', 'ylkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('170', '000585', '东北电气', 'dbdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('171', '000586', '汇源通信', 'hytx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('172', '000587', '金叶珠宝', 'jyzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('173', '000589', '黔轮胎A', 'qltA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('174', '000590', '紫光古汉', 'zggh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('175', '000591', '桐君阁', 'tjg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('176', '000592', '平潭发展', 'ptfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('177', '000593', '大通燃气', 'dtrq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('178', '000594', '*ST国恒', '*STgh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('179', '000595', '西北轴承', 'xbzc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('180', '000596', '古井贡酒', 'gjgj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('181', '000597', '东北制药', 'dbzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('182', '000598', '兴蓉投资', 'xrtz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('183', '000599', '青岛双星', 'qdsx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('184', '000600', '建投能源', 'jtny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('185', '000601', '韶能股份', 'sngf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('186', '000603', '盛达矿业', 'sdky', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('187', '000605', '渤海股份', 'bhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('188', '000606', '青海明胶', 'qhmj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('189', '000607', '华媒控股', 'hmkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('190', '000608', '阳光股份', 'yggf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('191', '000609', '绵世股份', 'msgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('192', '000610', '西安旅游', 'xaly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('193', '000611', '内蒙发展', 'nmfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('194', '000612', '焦作万方', 'jzwf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('195', '000613', '大东海A', 'ddhA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('196', '000615', '湖北金环', 'hbjh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('197', '000616', '海航投资', 'hhtz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('198', '000617', '石油济柴', 'syjc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('199', '000619', '海螺型材', 'hlxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('200', '000620', '新华联', 'xhl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('201', '000622', '恒立实业', 'hlsy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('202', '000623', '吉林敖东', 'jlad', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('203', '000625', '长安汽车', 'caqc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('204', '000626', '如意集团', 'ryjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('205', '000627', '天茂集团', 'tmjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('206', '000628', '高新发展', 'gxfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('207', '000629', '攀钢钒钛', 'pgft', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('208', '000630', '铜陵有色', 'tlys', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('209', '000631', '顺发恒业', 'sfhy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('210', '000632', '三木集团', 'smjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('211', '000633', '合金投资', 'hjtz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('212', '000635', '英力特', 'ylt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('213', '000636', '风华高科', 'fhgk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('214', '000637', '茂化实华', 'mhsh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('215', '000638', '万方发展', 'wffz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('216', '000639', '西王食品', 'xwsp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('217', '000650', '仁和药业', 'rhyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('218', '000651', '格力电器', 'gldq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('219', '000652', '泰达股份', 'tdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('220', '000655', '金岭矿业', 'jlky', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('221', '000656', '金科股份', 'jkgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('222', '000657', '中钨高新', 'zwgx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('223', '000659', '*ST中富', '*STzf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('224', '000661', '长春高新', 'ccgx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('225', '000662', '索芙特', 'sft', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('226', '000663', '永安林业', 'yaly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('227', '000665', '湖北广电', 'hbgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('228', '000666', '经纬纺机', 'jwfj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('229', '000667', '美好集团', 'mhjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('230', '000668', '荣丰控股', 'rfkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('231', '000669', '金鸿能源', 'jhny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('232', '000670', '盈方微', 'yfw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('233', '000671', '阳光城', 'ygc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('234', '000672', '上峰水泥', 'sfsn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('235', '000673', '当代东方', 'dddf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('236', '000676', '智度投资', 'zdtz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('237', '000677', '恒天海龙', 'hthl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('238', '000678', '襄阳轴承', 'xyzc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('239', '000679', '大连友谊', 'dlyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('240', '000680', '山推股份', 'stgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('241', '000681', '视觉中国', 'sjzg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('242', '000682', '东方电子', 'dfdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('243', '000683', '远兴能源', 'yxny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('244', '000685', '中山公用', 'zsgy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('245', '000686', '东北证券', 'dbzq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('246', '000687', '恒天天鹅', 'htte', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('247', '000688', '建新矿业', 'jxky', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('248', '000690', '宝新能源', 'bxny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('249', '000691', '亚太实业', 'ytsy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('250', '000692', '惠天热电', 'htrd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('251', '000693', '华泽钴镍', 'hzgn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('252', '000695', '滨海能源', 'bhny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('253', '000697', '炼石有色', 'lsys', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('254', '000698', '沈阳化工', 'syhg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('255', '000700', '模塑科技', 'mskj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('256', '000701', '厦门信达', 'xmxd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('257', '000702', '正虹科技', 'zhkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('258', '000703', '恒逸石化', 'hysh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('259', '000705', '浙江震元', 'zjzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('260', '000707', '双环科技', 'shkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('261', '000708', '大冶特钢', 'dytg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('262', '000709', '河北钢铁', 'hbgt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('263', '000710', '天兴仪表', 'txyb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('264', '000711', '京蓝科技', 'jlkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('265', '000712', '锦龙股份', 'jlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('266', '000713', '丰乐种业', 'flzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('267', '000715', '中兴商业', 'zxsy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('268', '000716', '黑芝麻', 'hzm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('269', '000717', '韶钢松山', 'sgss', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('270', '000718', '苏宁环球', 'snhq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('271', '000719', '大地传媒', 'ddcm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('272', '000720', '新能泰山', 'xnts', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('273', '000721', '西安饮食', 'xays', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('274', '000722', '湖南发展', 'hnfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('275', '000723', '美锦能源', 'mjny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('276', '000725', '京东方A', 'jdfA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('277', '000726', '鲁泰A', 'ltA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('278', '000727', '华东科技', 'hdkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('279', '000728', '国元证券', 'gyzq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('280', '000729', '燕京啤酒', 'yjpj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('281', '000731', '四川美丰', 'scmf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('282', '000732', '泰禾集团', 'thjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('283', '000733', '振华科技', 'zhkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('284', '000735', '罗牛山', 'lns', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('285', '000736', '中房地产', 'zfdc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('286', '000737', '南风化工', 'nfhg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('287', '000738', '中航动控', 'zhdk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('288', '000739', '普洛药业', 'plyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('289', '000748', '长城信息', 'ccxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('290', '000750', '国海证券', 'ghzq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('291', '000751', '锌业股份', 'xygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('292', '000752', '西藏发展', 'xcfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('293', '000753', '漳州发展', 'zzfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('294', '000755', '*ST三维', '*STsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('295', '000756', '新华制药', 'xhzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('296', '000757', '浩物股份', 'hwgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('297', '000758', '中色股份', 'zsgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('298', '000759', '中百集团', 'zbjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('299', '000760', '斯太尔', 'ste', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('300', '000761', '本钢板材', 'bgbc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('301', '000762', '西藏矿业', 'xcky', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('302', '000766', '通化金马', 'thjm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('303', '000767', '漳泽电力', 'zzdl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('304', '000768', '中航飞机', 'zhfj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('305', '000776', '广发证券', 'gfzq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('306', '000777', '中核科技', 'zhkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('307', '000778', '新兴铸管', 'xxzg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('308', '000779', '*ST派神', '*STps', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('309', '000780', '平庄能源', 'pzny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('310', '000782', '美达股份', 'mdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('311', '000783', '长江证券', 'cjzq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('312', '000785', '武汉中商', 'whzs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('313', '000786', '北新建材', 'bxjc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('314', '000788', '北大医药', 'bdyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('315', '000789', '万年青', 'wnq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('316', '000790', '华神集团', 'hsjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('317', '000791', '甘肃电投', 'gsdt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('318', '000792', '盐湖股份', 'yhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('319', '000793', '华闻传媒', 'hwcm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('320', '000795', '太原刚玉', 'tygy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('321', '000796', '易食股份', 'ysgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('322', '000797', '中国武夷', 'zgwy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('323', '000798', '中水渔业', 'zsyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('324', '000799', '酒鬼酒', 'jgj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('325', '000800', '一汽轿车', 'yqjc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('326', '000801', '四川九洲', 'scjz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('327', '000802', '北京文化', 'bjwh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('328', '000803', '金宇车城', 'jycc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('329', '000806', '银河投资', 'yhtz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('330', '000807', '云铝股份', 'ylgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('331', '000809', '铁岭新城', 'tlxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('332', '000810', '创维数字', 'cwsz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('333', '000811', '烟台冰轮', 'ytbl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('334', '000812', '陕西金叶', 'sxjy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('335', '000813', '天山纺织', 'tsfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('336', '000815', '美利纸业', 'mlzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('337', '000816', '江淮动力', 'jhdl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('338', '000818', '方大化工', 'fdhg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('339', '000819', '岳阳兴长', 'yyxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('340', '000820', '金城股份', 'jcgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('341', '000821', '京山轻机', 'jsqj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('342', '000822', '*ST海化', '*SThh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('343', '000823', '超声电子', 'csdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('344', '000825', '太钢不锈', 'tgbx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('345', '000826', '桑德环境', 'sdhj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('346', '000828', '东莞控股', 'dgkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('347', '000829', '天音控股', 'tykg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('348', '000830', '鲁西化工', 'lxhg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('349', '000831', '五矿稀土', 'wkxt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('350', '000833', '贵糖股份', 'gtgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('351', '000835', '长城动漫', 'ccdm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('352', '000836', '鑫茂科技', 'xmkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('353', '000837', '秦川机床', 'qcjc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('354', '000838', '国兴地产', 'gxdc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('355', '000839', '中信国安', 'zxga', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('356', '000848', '承德露露', 'cdll', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('357', '000850', '华茂股份', 'hmgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('358', '000851', '高鸿股份', 'ghgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('359', '000852', '江钻股份', 'jzgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('360', '000856', '冀东装备', 'jdzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('361', '000858', '五粮液', 'wly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('362', '000859', '国风塑业', 'gfsy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('363', '000860', '顺鑫农业', 'sxny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('364', '000861', '海印股份', 'hygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('365', '000862', '银星能源', 'yxny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('366', '000863', '三湘股份', 'sxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('367', '000868', '安凯客车', 'akkc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('368', '000869', '张裕A', 'zyA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('369', '000875', '吉电股份', 'jdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('370', '000876', '新希望', 'xxw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('371', '000877', '天山股份', 'tsgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('372', '000878', '云南铜业', 'ynty', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('373', '000880', '潍柴重机', 'wczj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('374', '000881', '大连国际', 'dlgj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('375', '000882', '华联股份', 'hlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('376', '000883', '湖北能源', 'hbny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('377', '000885', '同力水泥', 'tlsn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('378', '000886', '海南高速', 'hngs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('379', '000887', '中鼎股份', 'zdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('380', '000888', '峨眉山A', 'emsA', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('381', '000889', '茂业物流', 'mywl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('382', '000890', '法尔胜', 'fes', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('383', '000892', '星美联合', 'xmlh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('384', '000893', '东凌粮油', 'dlly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('385', '000895', '双汇发展', 'shfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('386', '000897', '津滨发展', 'jbfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('387', '000898', '鞍钢股份', 'aggf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('388', '000899', '赣能股份', 'gngf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('389', '000900', '现代投资', 'xdtz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('390', '000901', '航天科技', 'htkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('391', '000902', '新洋丰', 'xyf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('392', '000903', '云内动力', 'yndl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('393', '000905', '厦门港务', 'xmgw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('394', '000906', '物产中拓', 'wczt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('395', '000908', '天一科技', 'tykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('396', '000909', '数源科技', 'sykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('397', '000910', '大亚科技', 'dykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('398', '000911', '南宁糖业', 'nnty', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('399', '000912', '泸天化', 'lth', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('400', '000913', '钱江摩托', 'qjmt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('401', '000915', '山大华特', 'sdht', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('402', '000916', '华北高速', 'hbgs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('403', '000917', '电广传媒', 'dgcm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('404', '000918', '嘉凯城', 'jkc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('405', '000919', '金陵药业', 'jlyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('406', '000920', '南方汇通', 'nfht', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('407', '000921', '海信科龙', 'hxkl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('408', '000922', '佳电股份', 'jdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('409', '000923', '河北宣工', 'hbxg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('410', '000925', '众合机电', 'zhjd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('411', '000926', '福星股份', 'fxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('412', '000927', '一汽夏利', 'yqxl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('413', '000928', '中钢国际', 'zggj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('414', '000929', '兰州黄河', 'lzhh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('415', '000930', '中粮生化', 'zlsh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('416', '000931', '中关村', 'zgc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('417', '000932', '华菱钢铁', 'hlgt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('418', '000933', '神火股份', 'shgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('419', '000935', '四川双马', 'scsm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('420', '000936', '华西股份', 'hxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('421', '000937', '冀中能源', 'jzny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('422', '000938', '紫光股份', 'zggf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('423', '000939', '凯迪电力', 'kddl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('424', '000948', '南天信息', 'ntxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('425', '000949', '新乡化纤', 'xxhx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('426', '000950', '建峰化工', 'jfhg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('427', '000951', '中国重汽', 'zgzq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('428', '000952', '广济药业', 'gjyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('429', '000953', '河池化工', 'hchg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('430', '000955', '欣龙控股', 'xlkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('431', '000957', '中通客车', 'ztkc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('432', '000958', '东方能源', 'dfny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('433', '000959', '首钢股份', 'sggf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('434', '000960', '锡业股份', 'xygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('435', '000961', '中南建设', 'znjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('436', '000962', '东方钽业', 'dfty', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('437', '000963', '华东医药', 'hdyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('438', '000965', '天保基建', 'tbjj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('439', '000966', '长源电力', 'cydl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('440', '000967', '上风高科', 'sfgk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('441', '000968', '煤气化', 'mqh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('442', '000969', '安泰科技', 'atkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('443', '000970', '中科三环', 'zksh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('444', '000971', '蓝鼎控股', 'ldkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('445', '000972', '新中基', 'xzj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('446', '000973', '佛塑科技', 'fskj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('447', '000975', '银泰资源', 'ytzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('448', '000976', '春晖股份', 'chgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('449', '000977', '浪潮信息', 'lcxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('450', '000978', '桂林旅游', 'glly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('451', '000979', '中弘股份', 'zhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('452', '000980', '金马股份', 'jmgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('453', '000981', '银亿股份', 'yygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('454', '000982', '中银绒业', 'zyry', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('455', '000983', '西山煤电', 'xsmd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('456', '000985', '大庆华科', 'dqhk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('457', '000987', '广州友谊', 'gzyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('458', '000988', '华工科技', 'hgkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('459', '000989', '九芝堂', 'jzt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('460', '000990', '诚志股份', 'czgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('461', '000993', '闽东电力', 'mddl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('462', '000995', '皇台酒业', 'htjy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('463', '000996', '中国中期', 'zgzq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('464', '000997', '新大陆', 'xdl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('465', '000998', '隆平高科', 'lpgk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('466', '000999', '华润三九', 'hrsj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('467', '001696', '宗申动力', 'zsdl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('468', '001896', '豫能控股', 'ynkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('469', '002001', '新和成', 'xhc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('470', '002002', '鸿达兴业', 'hdxy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('471', '002003', '伟星股份', 'wxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('472', '002004', '华邦颖泰', 'hbyt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('473', '002005', '德豪润达', 'dhrd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('474', '002006', '精功科技', 'jgkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('475', '002007', '华兰生物', 'hlsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('476', '002008', '大族激光', 'dzjg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('477', '002009', '天奇股份', 'tqgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('478', '002010', '传化股份', 'chgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('479', '002011', '盾安环境', 'dahj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('480', '002012', '凯恩股份', 'kegf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('481', '002013', '中航机电', 'zhjd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('482', '002014', '永新股份', 'yxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('483', '002015', '*ST霞客', '*STxk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('484', '002016', '世荣兆业', 'srzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('485', '002017', '东信和平', 'dxhp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('486', '002018', '华信国际', 'hxgj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('487', '002019', '亿帆鑫富', 'yfxf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('488', '002020', '京新药业', 'jxyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('489', '002021', '中捷资源', 'zjzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('490', '002022', '科华生物', 'khsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('491', '002023', '海特高新', 'htgx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('492', '002024', '苏宁云商', 'snys', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('493', '002025', '航天电器', 'htdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('494', '002026', '山东威达', 'sdwd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('495', '002027', '七喜控股', 'qxkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('496', '002028', '思源电气', 'sydq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('497', '002029', '七匹狼', 'qpl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('498', '002030', '达安基因', 'dajy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('499', '002031', '巨轮股份', 'jlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('500', '002032', '苏泊尔', 'sbe', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('501', '002033', '丽江旅游', 'ljly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('502', '002034', '美欣达', 'mxd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('503', '002035', '华帝股份', 'hdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('504', '002036', '汉麻产业', 'hmcy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('505', '002037', '久联发展', 'jlfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('506', '002038', '双鹭药业', 'slyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('507', '002039', '黔源电力', 'qydl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('508', '002040', '南京港', 'njg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('509', '002041', '登海种业', 'dhzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('510', '002042', '华孚色纺', 'hfsf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('511', '002043', '兔宝宝', 'tbb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('512', '002044', '江苏三友', 'jssy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('513', '002045', '国光电器', 'ggdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('514', '002046', '轴研科技', 'zykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('515', '002047', '宝鹰股份', 'bygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('516', '002048', '宁波华翔', 'nbhx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('517', '002049', '同方国芯', 'tfgx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('518', '002050', '三花股份', 'shgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('519', '002051', '中工国际', 'zggj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('520', '002052', '同洲电子', 'tzdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('521', '002053', '云南盐化', 'ynyh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('522', '002054', '德美化工', 'dmhg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('523', '002055', '得润电子', 'drdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('524', '002056', '横店东磁', 'hddc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('525', '002057', '中钢天源', 'zgty', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('526', '002058', '威尔泰', 'wet', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('527', '002059', '云南旅游', 'ynly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('528', '002060', '粤水电', 'ysd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('529', '002061', '江山化工', 'jshg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('530', '002062', '宏润建设', 'hrjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('531', '002063', '远光软件', 'ygrj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('532', '002064', '华峰氨纶', 'hfal', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('533', '002065', '东华软件', 'dhrj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('534', '002066', '瑞泰科技', 'rtkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('535', '002067', '景兴纸业', 'jxzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('536', '002068', '黑猫股份', 'hmgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('537', '002069', '獐子岛', 'zzd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('538', '002070', '众和股份', 'zhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('539', '002071', '长城影视', 'ccys', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('540', '002072', '凯瑞德', 'krd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('541', '002073', '软控股份', 'rkgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('542', '002074', '东源电器', 'dydq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('543', '002075', '沙钢股份', 'sggf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('544', '002076', '雪莱特', 'xlt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('545', '002077', '大港股份', 'dggf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('546', '002078', '太阳纸业', 'tyzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('547', '002079', '苏州固锝', 'szgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('548', '002080', '中材科技', 'zckj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('549', '002081', '金螳螂', 'jtl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('550', '002082', '栋梁新材', 'dlxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('551', '002083', '孚日股份', 'frgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('552', '002084', '海鸥卫浴', 'howy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('553', '002085', '万丰奥威', 'wfaw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('554', '002086', '东方海洋', 'dfhy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('555', '002087', '新野纺织', 'xyfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('556', '002088', '鲁阳股份', 'lygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('557', '002089', '新海宜', 'xhy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('558', '002090', '金智科技', 'jzkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('559', '002091', '江苏国泰', 'jsgt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('560', '002092', '中泰化学', 'zthx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('561', '002093', '国脉科技', 'gmkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('562', '002094', '青岛金王', 'qdjw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('563', '002095', '生意宝', 'syb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('564', '002096', '南岭民爆', 'nlmb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('565', '002097', '山河智能', 'shzn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('566', '002098', '浔兴股份', 'xxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('567', '002099', '海翔药业', 'hxyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('568', '002100', '天康生物', 'tksw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('569', '002101', '广东鸿图', 'gdht', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('570', '002102', '冠福股份', 'gfgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('571', '002103', '广博股份', 'gbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('572', '002104', '恒宝股份', 'hbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('573', '002105', '信隆实业', 'xlsy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('574', '002106', '莱宝高科', 'lbgk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('575', '002107', '沃华医药', 'whyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('576', '002108', '沧州明珠', 'czmz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('577', '002109', '兴化股份', 'xhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('578', '002110', '三钢闽光', 'sgmg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('579', '002111', '威海广泰', 'whgt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('580', '002112', '三变科技', 'sbkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('581', '002113', '天润控股', 'trkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('582', '002114', '罗平锌电', 'lpxd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('583', '002115', '三维通信', 'swtx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('584', '002116', '中国海诚', 'zghc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('585', '002117', '东港股份', 'dggf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('586', '002118', '紫鑫药业', 'zxyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('587', '002119', '康强电子', 'kqdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('588', '002120', '新海股份', 'xhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('589', '002121', '科陆电子', 'kldz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('590', '002122', '天马股份', 'tmgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('591', '002123', '荣信股份', 'rxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('592', '002124', '天邦股份', 'tbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('593', '002125', '湘潭电化', 'xtdh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('594', '002126', '银轮股份', 'ylgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('595', '002127', '*ST新民', '*STxm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('596', '002128', '露天煤业', 'ltmy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('597', '002129', '中环股份', 'zhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('598', '002130', '沃尔核材', 'wehc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('599', '002131', '利欧股份', 'logf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('600', '002132', '恒星科技', 'hxkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('601', '002133', '广宇集团', 'gyjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('602', '002134', '*ST普林', '*STpl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('603', '002135', '东南网架', 'dnwj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('604', '002136', '安纳达', 'and', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('605', '002137', '实益达', 'syd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('606', '002138', '顺络电子', 'sldz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('607', '002139', '拓邦股份', 'tbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('608', '002140', '东华科技', 'dhkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('609', '002141', '蓉胜超微', 'rscw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('610', '002142', '宁波银行', 'nbyx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('611', '002143', '印纪传媒', 'yjcm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('612', '002144', '宏达高科', 'hdgk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('613', '002145', '中核钛白', 'zhtb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('614', '002146', '荣盛发展', 'rsfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('615', '002147', '方圆支承', 'fyzc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('616', '002148', '北纬通信', 'bwtx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('617', '002149', '西部材料', 'xbcl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('618', '002150', '通润装备', 'trzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('619', '002151', '北斗星通', 'bdxt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('620', '002152', '广电运通', 'gdyt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('621', '002153', '石基信息', 'sjxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('622', '002154', '报喜鸟', 'bxn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('623', '002155', '辰州矿业', 'czky', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('624', '002156', '通富微电', 'tfwd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('625', '002157', '正邦科技', 'zbkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('626', '002158', '汉钟精机', 'hzjj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('627', '002159', '三特索道', 'stsd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('628', '002160', '*ST常铝', '*STcl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('629', '002161', '远望谷', 'ywg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('630', '002162', '斯米克', 'smk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('631', '002163', '*ST三鑫', '*STsx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('632', '002164', '*ST东力', '*STdl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('633', '002165', '红宝丽', 'hbl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('634', '002166', '莱茵生物', 'lysw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('635', '002167', '东方锆业', 'dfgy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('636', '002168', '深圳惠程', 'szhc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('637', '002169', '智光电气', 'zgdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('638', '002170', '芭田股份', 'btgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('639', '002171', '精诚铜业', 'jcty', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('640', '002172', '澳洋科技', 'aykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('641', '002173', '千足珍珠', 'qzzz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('642', '002174', '游族网络', 'yzwl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('643', '002175', '广陆数测', 'glsc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('644', '002176', '江特电机', 'jtdj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('645', '002177', '御银股份', 'yygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('646', '002178', '延华智能', 'yhzn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('647', '002179', '中航光电', 'zhgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('648', '002180', '艾派克', 'apk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('649', '002181', '粤传媒', 'ycm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('650', '002182', '云海金属', 'yhjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('651', '002183', '怡亚通', 'yyt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('652', '002184', '海得控制', 'hdkz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('653', '002185', '华天科技', 'htkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('654', '002186', '全聚德', 'qjd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('655', '002187', '广百股份', 'gbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('656', '002188', '新嘉联', 'xjl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('657', '002189', '利达光电', 'ldgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('658', '002190', '成飞集成', 'cfjc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('659', '002191', '劲嘉股份', 'jjgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('660', '002192', '路翔股份', 'lxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('661', '002193', '山东如意', 'sdry', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('662', '002194', '武汉凡谷', 'whfg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('663', '002195', '海隆软件', 'hlrj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('664', '002196', '方正电机', 'fzdj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('665', '002197', '证通电子', 'ztdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('666', '002198', '嘉应制药', 'jyzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('667', '002199', '东晶电子', 'djdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('668', '002200', '云投生态', 'ytst', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('669', '002201', '九鼎新材', 'jdxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('670', '002202', '金风科技', 'jfkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('671', '002203', '海亮股份', 'hlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('672', '002204', '大连重工', 'dlzg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('673', '002205', '国统股份', 'gtgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('674', '002206', '海利得', 'hld', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('675', '002207', '准油股份', 'zygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('676', '002208', '合肥城建', 'hfcj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('677', '002209', '达意隆', 'dyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('678', '002210', '飞马国际', 'fmgj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('679', '002211', '宏达新材', 'hdxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('680', '002212', '南洋股份', 'nygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('681', '002213', '特尔佳', 'tej', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('682', '002214', '大立科技', 'dlkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('683', '002215', '诺普信', 'npx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('684', '002216', '三全食品', 'sqsp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('685', '002217', '*ST合泰', '*STht', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('686', '002218', '拓日新能', 'trxn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('687', '002219', '恒康医疗', 'hkyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('688', '002220', '天宝股份', 'tbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('689', '002221', '东华能源', 'dhny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('690', '002222', '福晶科技', 'fjkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('691', '002223', '鱼跃医疗', 'yyyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('692', '002224', '三力士', 'sls', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('693', '002225', '濮耐股份', 'pngf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('694', '002226', '江南化工', 'jnhg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('695', '002227', '奥特迅', 'atx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('696', '002228', '合兴包装', 'hxbz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('697', '002229', '鸿博股份', 'hbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('698', '002230', '科大讯飞', 'kdxf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('699', '002231', '奥维通信', 'awtx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('700', '002232', '启明信息', 'qmxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('701', '002233', '塔牌集团', 'tpjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('702', '002234', '*ST民和', '*STmh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('703', '002235', '安妮股份', 'angf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('704', '002236', '大华股份', 'dhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('705', '002237', '恒邦股份', 'hbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('706', '002238', '天威视讯', 'twsx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('707', '002239', '金飞达', 'jfd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('708', '002240', '威华股份', 'whgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('709', '002241', '歌尔声学', 'gesx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('710', '002242', '九阳股份', 'jygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('711', '002243', '通产丽星', 'tclx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('712', '002244', '滨江集团', 'bjjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('713', '002245', '澳洋顺昌', 'aysc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('714', '002246', '北化股份', 'bhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('715', '002247', '帝龙新材', 'dlxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('716', '002248', '*ST东数', '*STds', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('717', '002249', '大洋电机', 'dydj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('718', '002250', '联化科技', 'lhkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('719', '002251', '步步高', 'bbg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('720', '002252', '上海莱士', 'shls', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('721', '002253', '川大智胜', 'cdzs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('722', '002254', '泰和新材', 'thxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('723', '002255', '海陆重工', 'hlzg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('724', '002256', '彩虹精化', 'chjh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('725', '002258', '利尔化学', 'lehx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('726', '002259', '升达林业', 'sdly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('727', '002260', '伊立浦', 'ylp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('728', '002261', '拓维信息', 'twxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('729', '002262', '恩华药业', 'ehyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('730', '002263', '大东南', 'ddn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('731', '002264', '新华都', 'xhd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('732', '002265', '西仪股份', 'xygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('733', '002266', '浙富控股', 'zfkg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('734', '002267', '陕天然气', 'strq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('735', '002268', '卫士通', 'wst', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('736', '002269', '美邦服饰', 'mbfs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('737', '002270', '法因数控', 'fysk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('738', '002271', '东方雨虹', 'dfyh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('739', '002272', '川润股份', 'crgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('740', '002273', '水晶光电', 'sjgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('741', '002274', '华昌化工', 'hchg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('742', '002275', '桂林三金', 'glsj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('743', '002276', '万马股份', 'wmgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('744', '002277', '友阿股份', 'yagf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('745', '002278', '神开股份', 'skgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('746', '002279', '久其软件', 'jqrj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('747', '002280', '新世纪', 'xsj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('748', '002281', '光迅科技', 'gxkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('749', '002282', '博深工具', 'bsgj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('750', '002283', '天润曲轴', 'trqz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('751', '002284', '亚太股份', 'ytgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('752', '002285', '世联行', 'slx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('753', '002286', '保龄宝', 'blb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('754', '002287', '奇正藏药', 'qzcy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('755', '002288', '超华科技', 'chkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('756', '002289', '宇顺电子', 'ysdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('757', '002290', '禾盛新材', 'hsxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('758', '002291', '星期六', 'xql', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('759', '002292', '奥飞动漫', 'afdm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('760', '002293', '罗莱家纺', 'lljf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('761', '002294', '信立泰', 'xlt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('762', '002295', '精艺股份', 'jygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('763', '002296', '辉煌科技', 'hhkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('764', '002297', '博云新材', 'byxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('765', '002298', '鑫龙电器', 'xldq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('766', '002299', '圣农发展', 'snfz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('767', '002300', '太阳电缆', 'tydl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('768', '002301', '齐心集团', 'qxjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('769', '002302', '西部建设', 'xbjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('770', '002303', '美盈森', 'mys', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('771', '002304', '洋河股份', 'yhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('772', '002305', '南国置业', 'ngzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('773', '002306', '中科云网', 'zkyw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('774', '002307', '北新路桥', 'bxlq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('775', '002308', '威创股份', 'wcgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('776', '002309', '中利科技', 'zlkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('777', '002310', '东方园林', 'dfyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('778', '002311', '海大集团', 'hdjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('779', '002312', '三泰电子', 'stdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('780', '002313', '日海通讯', 'rhtx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('781', '002314', '雅致股份', 'yzgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('782', '002315', '焦点科技', 'jdkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('783', '002316', '键桥通讯', 'jqtx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('784', '002317', '众生药业', 'zsyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('785', '002318', '久立特材', 'jltc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('786', '002319', '乐通股份', 'ltgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('787', '002320', '海峡股份', 'hxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('788', '002321', '华英农业', 'hyny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('789', '002322', '理工监测', 'lgjc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('790', '002323', '中联电气', 'zldq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('791', '002324', '普利特', 'plt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('792', '002325', '洪涛股份', 'htgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('793', '002326', '永太科技', 'ytkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('794', '002327', '富安娜', 'fan', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('795', '002328', '新朋股份', 'xpgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('796', '002329', '皇氏集团', 'hsjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('797', '002330', '得利斯', 'dls', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('798', '002331', '皖通科技', 'wtkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('799', '002332', '仙琚制药', 'xjzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('800', '002333', '罗普斯金', 'lpsj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('801', '002334', '英威腾', 'ywt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('802', '002335', '科华恒盛', 'khhs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('803', '002336', '人人乐', 'rrl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('804', '002337', '赛象科技', 'sxkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('805', '002338', '奥普光电', 'apgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('806', '002339', '积成电子', 'jcdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('807', '002340', '格林美', 'glm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('808', '002341', '新纶科技', 'xlkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('809', '002342', '巨力索具', 'jlsj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('810', '002343', '禾欣股份', 'hxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('811', '002344', '海宁皮城', 'hnpc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('812', '002345', '潮宏基', 'chj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('813', '002346', '柘中建设', 'zzjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('814', '002347', '泰尔重工', 'tezg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('815', '002348', '高乐股份', 'glgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('816', '002349', '精华制药', 'jhzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('817', '002350', '北京科锐', 'bjkr', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('818', '002351', '漫步者', 'mbz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('819', '002352', '鼎泰新材', 'dtxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('820', '002353', '杰瑞股份', 'jrgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('821', '002354', '科冕木业', 'kmmy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('822', '002355', '兴民钢圈', 'xmgq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('823', '002356', '浩宁达', 'hnd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('824', '002357', '富临运业', 'flyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('825', '002358', '森源电气', 'sydq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('826', '002359', '齐星铁塔', 'qxtt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('827', '002360', '同德化工', 'tdhg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('828', '002361', '神剑股份', 'sjgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('829', '002362', '汉王科技', 'hwkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('830', '002363', '隆基机械', 'ljjx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('831', '002364', '中恒电气', 'zhdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('832', '002365', '永安药业', 'yayy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('833', '002366', '丹甫股份', 'dfgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('834', '002367', '康力电梯', 'kldt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('835', '002368', '太极股份', 'tjgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('836', '002369', '卓翼科技', 'zykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('837', '002370', '亚太药业', 'ytyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('838', '002371', '七星电子', 'qxdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('839', '002372', '伟星新材', 'wxxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('840', '002373', '千方科技', 'qfkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('841', '002374', '丽鹏股份', 'lpgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('842', '002375', '亚厦股份', 'yxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('843', '002376', '新北洋', 'xby', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('844', '002377', '国创高新', 'gcgx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('845', '002378', '章源钨业', 'zywy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('846', '002379', '鲁丰环保', 'lfhb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('847', '002380', '科远股份', 'kygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('848', '002381', '双箭股份', 'sjgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('849', '002382', '蓝帆医疗', 'lfyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('850', '002383', '合众思壮', 'hzsz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('851', '002384', '东山精密', 'dsjm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('852', '002385', '大北农', 'dbn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('853', '002386', '天原集团', 'tyjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('854', '002387', '黑牛食品', 'hnsp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('855', '002388', '新亚制程', 'xyzc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('856', '002389', '南洋科技', 'nykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('857', '002390', '信邦制药', 'xbzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('858', '002391', '长青股份', 'cqgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('859', '002392', '北京利尔', 'bjle', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('860', '002393', '力生制药', 'lszy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('861', '002394', '联发股份', 'lfgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('862', '002395', '双象股份', 'sxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('863', '002396', '星网锐捷', 'xwrj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('864', '002397', '梦洁家纺', 'mjjf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('865', '002398', '建研集团', 'jyjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('866', '002399', '海普瑞', 'hpr', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('867', '002400', '省广股份', 'sggf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('868', '002401', '中海科技', 'zhkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('869', '002402', '和而泰', 'het', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('870', '002403', '爱仕达', 'asd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('871', '002404', '嘉欣丝绸', 'jxsc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('872', '002405', '四维图新', 'swtx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('873', '002406', '远东传动', 'ydcd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('874', '002407', '多氟多', 'dfd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('875', '002408', '齐翔腾达', 'qxtd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('876', '002409', '雅克科技', 'ykkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('877', '002410', '广联达', 'gld', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('878', '002411', '九九久', 'jjj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('879', '002412', '汉森制药', 'hszy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('880', '002413', '常发股份', 'cfgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('881', '002414', '高德红外', 'gdhw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('882', '002415', '海康威视', 'hkws', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('883', '002416', '爱施德', 'asd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('884', '002417', '三元达', 'syd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('885', '002418', '康盛股份', 'ksgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('886', '002419', '天虹商场', 'thsc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('887', '002420', '毅昌股份', 'ycgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('888', '002421', '达实智能', 'dszn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('889', '002422', '科伦药业', 'klyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('890', '002423', '中原特钢', 'zytg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('891', '002424', '贵州百灵', 'gzbl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('892', '002425', '凯撒股份', 'ksgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('893', '002426', '胜利精密', 'sljm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('894', '002427', '尤夫股份', 'yfgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('895', '002428', '云南锗业', 'ynzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('896', '002429', '兆驰股份', 'zcgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('897', '002430', '杭氧股份', 'hygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('898', '002431', '棕榈园林', 'zlyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('899', '002432', '九安医疗', 'jayl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('900', '002433', '太安堂', 'tat', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('901', '002434', '万里扬', 'wly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('902', '002435', '长江润发', 'cjrf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('903', '002436', '兴森科技', 'xskj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('904', '002437', '誉衡药业', 'yhyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('905', '002438', '江苏神通', 'jsst', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('906', '002439', '启明星辰', 'qmxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('907', '002440', '闰土股份', 'rtgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('908', '002441', '众业达', 'zyd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('909', '002442', '龙星化工', 'lxhg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('910', '002443', '金洲管道', 'jzgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('911', '002444', '巨星科技', 'jxkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('912', '002445', '中南重工', 'znzg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('913', '002446', '盛路通信', 'sltx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('914', '002447', '壹桥海参', 'yqhc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('915', '002448', '中原内配', 'zynp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('916', '002449', '国星光电', 'gxgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('917', '002450', '康得新', 'kdx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('918', '002451', '摩恩电气', 'medq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('919', '002452', '长高集团', 'cgjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('920', '002453', '天马精化', 'tmjh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('921', '002454', '松芝股份', 'szgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('922', '002455', '百川股份', 'bcgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('923', '002456', '欧菲光', 'ofg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('924', '002457', '青龙管业', 'qlgy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('925', '002458', '益生股份', 'ysgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('926', '002459', '*ST天业', '*STty', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('927', '002460', '赣锋锂业', 'gfly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('928', '002461', '珠江啤酒', 'zjpj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('929', '002462', '嘉事堂', 'jst', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('930', '002463', '沪电股份', 'hdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('931', '002464', '金利科技', 'jlkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('932', '002465', '海格通信', 'hgtx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('933', '002466', '天齐锂业', 'tqly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('934', '002467', '二六三', 'els', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('935', '002468', '艾迪西', 'adx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('936', '002469', '三维工程', 'swgc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('937', '002470', '金正大', 'jzd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('938', '002471', '中超电缆', 'zcdl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('939', '002472', '双环传动', 'shcd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('940', '002473', '圣莱达', 'sld', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('941', '002474', '榕基软件', 'rjrj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('942', '002475', '立讯精密', 'lxjm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('943', '002476', '宝莫股份', 'bmgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('944', '002477', '雏鹰农牧', 'cynm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('945', '002478', '常宝股份', 'cbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('946', '002479', '富春环保', 'fchb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('947', '002480', '新筑股份', 'xzgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('948', '002481', '双塔食品', 'stsp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('949', '002482', '广田股份', 'gtgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('950', '002483', '润邦股份', 'rbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('951', '002484', '江海股份', 'jhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('952', '002485', '希努尔', 'xne', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('953', '002486', '嘉麟杰', 'jlj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('954', '002487', '大金重工', 'djzg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('955', '002488', '金固股份', 'jggf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('956', '002489', '浙江永强', 'zjyq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('957', '002490', '山东墨龙', 'sdml', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('958', '002491', '通鼎互联', 'tdhl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('959', '002492', '恒基达鑫', 'hjdx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('960', '002493', '荣盛石化', 'rssh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('961', '002494', '华斯股份', 'hsgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('962', '002495', '佳隆股份', 'jlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('963', '002496', '辉丰股份', 'hfgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('964', '002497', '雅化集团', 'yhjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('965', '002498', '汉缆股份', 'hlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('966', '002499', '科林环保', 'klhb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('967', '002500', '山西证券', 'sxzq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('968', '002501', '利源精制', 'lyjz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('969', '002502', '骅威股份', 'hwgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('970', '002503', '搜于特', 'syt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('971', '002504', '东光微电', 'dgwd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('972', '002505', '大康牧业', 'dkmy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('973', '002506', '*ST超日', '*STcr', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('974', '002507', '涪陵榨菜', 'flzc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('975', '002508', '老板电器', 'lbdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('976', '002509', '天广消防', 'tgxf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('977', '002510', '天汽模', 'tqm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('978', '002511', '中顺洁柔', 'zsjr', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('979', '002512', '达华智能', 'dhzn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('980', '002513', '蓝丰生化', 'lfsh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('981', '002514', '宝馨科技', 'bxkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('982', '002515', '金字火腿', 'jzht', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('983', '002516', '江苏旷达', 'jskd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('984', '002517', '泰亚股份', 'tygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('985', '002518', '科士达', 'ksd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('986', '002519', '银河电子', 'yhdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('987', '002520', '日发精机', 'rfjj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('988', '002521', '齐峰新材', 'qfxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('989', '002522', '浙江众成', 'zjzc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('990', '002523', '天桥起重', 'tqqz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('991', '002524', '光正集团', 'gzjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('992', '002526', '山东矿机', 'sdkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('993', '002527', '新时达', 'xsd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('994', '002528', '英飞拓', 'yft', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('995', '002529', '海源机械', 'hyjx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('996', '002530', '丰东股份', 'fdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('997', '002531', '天顺风能', 'tsfn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('998', '002532', '新界泵业', 'xjby', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('999', '002533', '金杯电工', 'jbdg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1000', '002534', '杭锅股份', 'hggf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1001', '002535', '林州重机', 'lzzj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1002', '002536', '西泵股份', 'xbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1003', '002537', '海立美达', 'hlmd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1004', '002538', '司尔特', 'set', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1005', '002539', '新都化工', 'xdhg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1006', '002540', '亚太科技', 'ytkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1007', '002541', '鸿路钢构', 'hlgg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1008', '002542', '中化岩土', 'zhyt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1009', '002543', '万和电气', 'whdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1010', '002544', '杰赛科技', 'jskj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1011', '002545', '东方铁塔', 'dftt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1012', '002546', '新联电子', 'xldz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1013', '002547', '春兴精工', 'cxjg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1014', '002548', '金新农', 'jxn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1015', '002549', '凯美特气', 'kmtq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1016', '002550', '千红制药', 'qhzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1017', '002551', '尚荣医疗', 'sryl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1018', '002552', '宝鼎重工', 'bdzg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1019', '002553', '南方轴承', 'nfzc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1020', '002554', '惠博普', 'hbp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1021', '002555', '顺荣三七', 'srsq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1022', '002556', '辉隆股份', 'hlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1023', '002557', '洽洽食品', 'qqsp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1024', '002558', '世纪游轮', 'sjyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1025', '002559', '亚威股份', 'ywgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1026', '002560', '通达股份', 'tdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1027', '002561', '徐家汇', 'xjh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1028', '002562', '兄弟科技', 'xdkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1029', '002563', '森马服饰', 'smfs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1030', '002564', '天沃科技', 'twkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1031', '002565', '上海绿新', 'shlx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1032', '002566', '益盛药业', 'ysyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1033', '002567', '唐人神', 'trs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1034', '002568', '百润股份', 'brgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1035', '002569', '步森股份', 'bsgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1036', '002570', '贝因美', 'bym', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1037', '002571', '德力股份', 'dlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1038', '002572', '索菲亚', 'sfy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1039', '002573', '国电清新', 'gdqx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1040', '002574', '明牌珠宝', 'mpzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1041', '002575', '群兴玩具', 'qxwj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1042', '002576', '通达动力', 'tddl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1043', '002577', '雷柏科技', 'lbkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1044', '002578', '闽发铝业', 'mfly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1045', '002579', '中京电子', 'zjdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1046', '002580', '圣阳股份', 'sygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1047', '002581', '万昌科技', 'wckj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1048', '002582', '好想你', 'hxn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1049', '002583', '海能达', 'hnd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1050', '002584', '西陇化工', 'xlhg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1051', '002585', '双星新材', 'sxxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1052', '002586', '围海股份', 'whgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1053', '002587', '奥拓电子', 'atdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1054', '002588', '史丹利', 'sdl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1055', '002589', '瑞康医药', 'rkyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1056', '002590', '万安科技', 'wakj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1057', '002591', '恒大高新', 'hdgx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1058', '002592', '八菱科技', 'blkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1059', '002593', '日上集团', 'rsjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1060', '002594', '比亚迪', 'byd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1061', '002595', '豪迈科技', 'hmkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1062', '002596', '海南瑞泽', 'hnrz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1063', '002597', '金禾实业', 'jhsy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1064', '002598', '山东章鼓', 'sdzg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1065', '002599', '盛通股份', 'stgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1066', '002600', '江粉磁材', 'jfcc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1067', '002601', '佰利联', 'bll', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1068', '002602', '世纪华通', 'sjht', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1069', '002603', '以岭药业', 'ylyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1070', '002604', '龙力生物', 'llsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1071', '002605', '姚记扑克', 'yjpk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1072', '002606', '大连电瓷', 'dldc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1073', '002607', '亚夏汽车', 'yxqc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1074', '002608', '舜天船舶', 'stcb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1075', '002609', '捷顺科技', 'jskj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1076', '002610', '爱康科技', 'akkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1077', '002611', '东方精工', 'dfjg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1078', '002612', '朗姿股份', 'lzgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1079', '002613', '北玻股份', 'bbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1080', '002614', '蒙发利', 'mfl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1081', '002615', '哈尔斯', 'hes', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1082', '002616', '长青集团', 'cqjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1083', '002617', '露笑科技', 'lxkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1084', '002618', '丹邦科技', 'dbkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1085', '002619', '巨龙管业', 'jlgy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1086', '002620', '瑞和股份', 'rhgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1087', '002621', '大连三垒', 'dlsl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1088', '002622', '永大集团', 'ydjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1089', '002623', '亚玛顿', 'ymd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1090', '002624', '金磊股份', 'jlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1091', '002625', '龙生股份', 'lsgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1092', '002626', '金达威', 'jdw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1093', '002627', '宜昌交运', 'ycjy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1094', '002628', '成都路桥', 'cdlq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1095', '002629', '仁智油服', 'rzyf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1096', '002630', '华西能源', 'hxny', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1097', '002631', '德尔家居', 'dejj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1098', '002632', '道明光学', 'dmgx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1099', '002633', '*ST申科', '*STsk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1100', '002634', '棒杰股份', 'bjgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1101', '002635', '安洁科技', 'ajkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1102', '002636', '金安国纪', 'jagj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1103', '002637', '赞宇科技', 'zykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1104', '002638', '勤上光电', 'qsgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1105', '002639', '雪人股份', 'xrgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1106', '002640', '百圆裤业', 'byky', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1107', '002641', '永高股份', 'yggf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1108', '002642', '荣之联', 'rzl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1109', '002643', '烟台万润', 'ytwr', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1110', '002644', '佛慈制药', 'fczy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1111', '002645', '华宏科技', 'hhkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1112', '002646', '青青稞酒', 'qqkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1113', '002647', '宏磊股份', 'hlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1114', '002648', '卫星石化', 'wxsh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1115', '002649', '博彦科技', 'bykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1116', '002650', '加加食品', 'jjsp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1117', '002651', '利君股份', 'ljgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1118', '002652', '扬子新材', 'yzxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1119', '002653', '海思科', 'hsk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1120', '002654', '万润科技', 'wrkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1121', '002655', '共达电声', 'gdds', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1122', '002656', '卡奴迪路', 'kndl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1123', '002657', '中科金财', 'zkjc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1124', '002658', '雪迪龙', 'xdl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1125', '002659', '中泰桥梁', 'ztql', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1126', '002660', '茂硕电源', 'msdy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1127', '002661', '克明面业', 'kmmy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1128', '002662', '京威股份', 'jwgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1129', '002663', '普邦园林', 'pbyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1130', '002664', '信质电机', 'xzdj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1131', '002665', '首航节能', 'shjn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1132', '002666', '德联集团', 'dljt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1133', '002667', '鞍重股份', 'azgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1134', '002668', '奥马电器', 'amdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1135', '002669', '康达新材', 'kdxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1136', '002670', '华声股份', 'hsgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1137', '002671', '龙泉股份', 'lqgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1138', '002672', '东江环保', 'djhb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1139', '002673', '西部证券', 'xbzq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1140', '002674', '兴业科技', 'xykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1141', '002675', '东诚药业', 'dcyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1142', '002676', '顺威股份', 'swgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1143', '002677', '浙江美大', 'zjmd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1144', '002678', '珠江钢琴', 'zjgq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1145', '002679', '福建金森', 'fjjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1146', '002680', '黄海机械', 'hhjx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1147', '002681', '奋达科技', 'fdkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1148', '002682', '龙洲股份', 'lzgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1149', '002683', '宏大爆破', 'hdbp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1150', '002684', '猛狮科技', 'mskj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1151', '002685', '华东重机', 'hdzj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1152', '002686', '亿利达', 'yld', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1153', '002687', '乔治白', 'qzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1154', '002688', '金河生物', 'jhsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1155', '002689', '博林特', 'blt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1156', '002690', '美亚光电', 'mygd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1157', '002691', '石中装备', 'szzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1158', '002692', '远程电缆', 'ycdl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1159', '002693', '双成药业', 'scyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1160', '002694', '顾地科技', 'gdkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1161', '002695', '煌上煌', 'hsh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1162', '002696', '百洋股份', 'bygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1163', '002697', '红旗连锁', 'hqls', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1164', '002698', '博实股份', 'bsgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1165', '002699', '美盛文化', 'mswh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1166', '002700', '新疆浩源', 'xjhy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1167', '002701', '奥瑞金', 'arj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1168', '002702', '海欣食品', 'hxsp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1169', '002703', '浙江世宝', 'zjsb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1170', '002705', '新宝股份', 'xbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1171', '002706', '良信电器', 'lxdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1172', '002707', '众信旅游', 'zxly', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1173', '002708', '光洋股份', 'gygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1174', '002709', '天赐材料', 'tccl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1175', '002711', '欧浦钢网', 'opgw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1176', '002712', '思美传媒', 'smcm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1177', '002713', '东易日盛', 'dyrs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1178', '002714', '牧原股份', 'mygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1179', '002715', '登云股份', 'dygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1180', '002716', '金贵银业', 'jgyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1181', '002717', '岭南园林', 'lnyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1182', '002718', '友邦吊顶', 'ybdd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1183', '002719', '麦趣尔', 'mqe', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1184', '002721', '金一文化', 'jywh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1185', '002722', '金轮股份', 'jlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1186', '002723', '金莱特', 'jlt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1187', '002724', '海洋王', 'hyw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1188', '002725', '跃岭股份', 'ylgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1189', '002726', '龙大肉食', 'ldrs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1190', '002727', '一心堂', 'yxt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1191', '002728', '台城制药', 'tczy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1192', '002729', '好利来', 'hll', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1193', '002730', '电光科技', 'dgkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1194', '002731', '萃华珠宝', 'chzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1195', '002732', '燕塘乳业', 'ytry', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1196', '002733', '雄韬股份', 'xtgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1197', '002734', '利民股份', 'lmgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1198', '002735', '王子新材', 'wzxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1199', '002736', '国信证券', 'gxzq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1200', '002737', '葵花药业', 'khyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1201', '002738', '中矿资源', 'zkzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1202', '002739', '万达院线', 'wdyx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1203', '002740', '爱迪尔', 'ade', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1204', '002741', '光华科技', 'ghkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1205', '002742', '三圣特材', 'sstc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1206', '002743', '富煌钢构', 'fhgg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1207', '002745', '木林森', 'mls', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1208', '002746', '仙坛股份', 'xtgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1209', '300001', '特锐德', 'trd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1210', '300002', '神州泰岳', 'szty', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1211', '300003', '乐普医疗', 'lpyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1212', '300004', '南风股份', 'nfgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1213', '300005', '探路者', 'tlz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1214', '300006', '莱美药业', 'lmyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1215', '300007', '汉威电子', 'hwdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1216', '300008', '上海佳豪', 'shjh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1217', '300009', '安科生物', 'aksw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1218', '300010', '立思辰', 'lsc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1219', '300011', '鼎汉技术', 'dhjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1220', '300012', '华测检测', 'hcjc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1221', '300013', '新宁物流', 'xnwl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1222', '300014', '亿纬锂能', 'ywln', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1223', '300015', '爱尔眼科', 'aeyk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1224', '300016', '北陆药业', 'blyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1225', '300017', '网宿科技', 'wskj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1226', '300018', '中元华电', 'zyhd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1227', '300019', '硅宝科技', 'gbkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1228', '300020', '银江股份', 'yjgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1229', '300021', '大禹节水', 'dyjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1230', '300022', '吉峰农机', 'jfnj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1231', '300023', '宝德股份', 'bdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1232', '300024', '机器人', 'jqr', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1233', '300025', '华星创业', 'hxcy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1234', '300026', '红日药业', 'hryy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1235', '300027', '华谊兄弟', 'hyxd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1236', '300028', '金亚科技', 'jykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1237', '300029', '天龙光电', 'tlgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1238', '300030', '阳普医疗', 'ypyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1239', '300031', '宝通带业', 'btdy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1240', '300032', '金龙机电', 'jljd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1241', '300033', '同花顺', 'ths', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1242', '300034', '钢研高纳', 'gygn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1243', '300035', '中科电气', 'zkdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1244', '300036', '超图软件', 'ctrj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1245', '300037', '新宙邦', 'xzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1246', '300038', '梅泰诺', 'mtn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1247', '300039', '上海凯宝', 'shkb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1248', '300040', '九洲电气', 'jzdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1249', '300041', '回天新材', 'htxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1250', '300042', '朗科科技', 'lkkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1251', '300043', '互动娱乐', 'hdyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1252', '300044', '赛为智能', 'swzn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1253', '300045', '华力创通', 'hlct', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1254', '300046', '台基股份', 'tjgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1255', '300047', '天源迪科', 'tydk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1256', '300048', '合康变频', 'hkbp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1257', '300049', '福瑞股份', 'frgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1258', '300050', '世纪鼎利', 'sjdl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1259', '300051', '三五互联', 'swhl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1260', '300052', '中青宝', 'zqb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1261', '300053', '欧比特', 'obt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1262', '300054', '鼎龙股份', 'dlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1263', '300055', '万邦达', 'wbd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1264', '300056', '三维丝', 'sws', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1265', '300057', '万顺股份', 'wsgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1266', '300058', '蓝色光标', 'lsgb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1267', '300059', '东方财富', 'dfcf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1268', '300061', '康耐特', 'knt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1269', '300062', '中能电气', 'zndq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1270', '300063', '天龙集团', 'tljt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1271', '300064', '豫金刚石', 'yjgs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1272', '300065', '海兰信', 'hlx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1273', '300066', '三川股份', 'scgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1274', '300067', '安诺其', 'anq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1275', '300068', '南都电源', 'nddy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1276', '300069', '金利华电', 'jlhd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1277', '300070', '碧水源', 'bsy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1278', '300071', '华谊嘉信', 'hyjx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1279', '300072', '三聚环保', 'sjhb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1280', '300073', '当升科技', 'dskj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1281', '300074', '华平股份', 'hpgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1282', '300075', '数字政通', 'szzt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1283', '300076', 'GQY视讯', 'GQYsx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1284', '300077', '国民技术', 'gmjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1285', '300078', '中瑞思创', 'zrsc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1286', '300079', '数码视讯', 'smsx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1287', '300080', '新大新材', 'xdxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1288', '300081', '恒信移动', 'hxyd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1289', '300082', '奥克股份', 'akgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1290', '300083', '劲胜精密', 'jsjm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1291', '300084', '海默科技', 'hmkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1292', '300085', '银之杰', 'yzj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1293', '300086', '康芝药业', 'kzyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1294', '300087', '荃银高科', 'qygk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1295', '300088', '长信科技', 'cxkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1296', '300089', '长城集团', 'ccjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1297', '300090', '盛运股份', 'sygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1298', '300091', '金通灵', 'jtl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1299', '300092', '科新机电', 'kxjd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1300', '300093', '金刚玻璃', 'jgbl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1301', '300094', '国联水产', 'glsc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1302', '300095', '华伍股份', 'hwgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1303', '300096', '易联众', 'ylz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1304', '300097', '智云股份', 'zygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1305', '300098', '高新兴', 'gxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1306', '300099', '尤洛卡', 'ylk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1307', '300100', '双林股份', 'slgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1308', '300101', '振芯科技', 'zxkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1309', '300102', '乾照光电', 'qzgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1310', '300103', '达刚路机', 'dglj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1311', '300104', '乐视网', 'lsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1312', '300105', '龙源技术', 'lyjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1313', '300106', '西部牧业', 'xbmy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1314', '300107', '建新股份', 'jxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1315', '300108', '双龙股份', 'slgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1316', '300109', '新开源', 'xky', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1317', '300110', '华仁药业', 'hryy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1318', '300111', '向日葵', 'xrk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1319', '300112', '万讯自控', 'wxzk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1320', '300113', '顺网科技', 'swkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1321', '300114', '中航电测', 'zhdc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1322', '300115', '长盈精密', 'cyjm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1323', '300116', '坚瑞消防', 'jrxf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1324', '300117', '嘉寓股份', 'jygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1325', '300118', '东方日升', 'dfrs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1326', '300119', '瑞普生物', 'rpsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1327', '300120', '经纬电材', 'jwdc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1328', '300121', '阳谷华泰', 'yght', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1329', '300122', '智飞生物', 'zfsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1330', '300123', '太阳鸟', 'tyn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1331', '300124', '汇川技术', 'hcjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1332', '300125', '易世达', 'ysd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1333', '300126', '锐奇股份', 'rqgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1334', '300127', '银河磁体', 'yhct', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1335', '300128', '锦富新材', 'jfxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1336', '300129', '泰胜风能', 'tsfn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1337', '300130', '新国都', 'xgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1338', '300131', '英唐智控', 'ytzk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1339', '300132', '青松股份', 'qsgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1340', '300133', '华策影视', 'hcys', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1341', '300134', '大富科技', 'dfkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1342', '300135', '宝利沥青', 'bllq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1343', '300136', '信维通信', 'xwtx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1344', '300137', '先河环保', 'xhhb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1345', '300138', '晨光生物', 'cgsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1346', '300139', '福星晓程', 'fxxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1347', '300140', '启源装备', 'qyzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1348', '300141', '和顺电气', 'hsdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1349', '300142', '沃森生物', 'wssw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1350', '300143', '星河生物', 'xhsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1351', '300144', '宋城演艺', 'scyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1352', '300145', '南方泵业', 'nfby', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1353', '300146', '汤臣倍健', 'tcbj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1354', '300147', '香雪制药', 'xxzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1355', '300148', '天舟文化', 'tzwh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1356', '300149', '量子高科', 'lzgk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1357', '300150', '世纪瑞尔', 'sjre', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1358', '300151', '昌红科技', 'chkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1359', '300152', '燃控科技', 'rkkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1360', '300153', '科泰电源', 'ktdy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1361', '300154', '瑞凌股份', 'rlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1362', '300155', '安居宝', 'ajb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1363', '300156', '神雾环保', 'swhb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1364', '300157', '恒泰艾普', 'htap', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1365', '300158', '振东制药', 'zdzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1366', '300159', '新研股份', 'xygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1367', '300160', '秀强股份', 'xqgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1368', '300161', '华中数控', 'hzsk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1369', '300162', '雷曼光电', 'lmgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1370', '300163', '先锋新材', 'xfxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1371', '300164', '通源石油', 'tysy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1372', '300165', '天瑞仪器', 'tryq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1373', '300166', '东方国信', 'dfgx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1374', '300167', '迪威视讯', 'dwsx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1375', '300168', '万达信息', 'wdxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1376', '300169', '天晟新材', 'tsxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1377', '300170', '汉得信息', 'hdxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1378', '300171', '东富龙', 'dfl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1379', '300172', '中电环保', 'zdhb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1380', '300173', '松德股份', 'sdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1381', '300174', '元力股份', 'ylgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1382', '300175', '朗源股份', 'lygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1383', '300176', '鸿特精密', 'htjm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1384', '300177', '中海达', 'zhd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1385', '300178', '腾邦国际', 'tbgj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1386', '300179', '四方达', 'sfd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1387', '300180', '华峰超纤', 'hfcx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1388', '300181', '佐力药业', 'zlyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1389', '300182', '捷成股份', 'jcgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1390', '300183', '东软载波', 'drzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1391', '300184', '力源信息', 'lyxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1392', '300185', '通裕重工', 'tyzg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1393', '300186', '大华农', 'dhn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1394', '300187', '永清环保', 'yqhb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1395', '300188', '美亚柏科', 'mybk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1396', '300189', '神农大丰', 'sndf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1397', '300190', '维尔利', 'wel', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1398', '300191', '潜能恒信', 'qnhx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1399', '300192', '科斯伍德', 'kswd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1400', '300193', '佳士科技', 'jskj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1401', '300194', '福安药业', 'fayy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1402', '300195', '长荣股份', 'crgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1403', '300196', '长海股份', 'chgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1404', '300197', '铁汉生态', 'thst', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1405', '300198', '纳川股份', 'ncgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1406', '300199', '翰宇药业', 'hyyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1407', '300200', '高盟新材', 'gmxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1408', '300201', '海伦哲', 'hlz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1409', '300202', '聚龙股份', 'jlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1410', '300203', '聚光科技', 'jgkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1411', '300204', '舒泰神', 'sts', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1412', '300205', '天喻信息', 'tyxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1413', '300206', '理邦仪器', 'lbyq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1414', '300207', '欣旺达', 'xwd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1415', '300208', '恒顺电气', 'hsdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1416', '300209', '天泽信息', 'tzxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1417', '300210', '森远股份', 'sygf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1418', '300211', '亿通科技', 'ytkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1419', '300212', '易华录', 'yhl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1420', '300213', '佳讯飞鸿', 'jxfh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1421', '300214', '日科化学', 'rkhx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1422', '300215', '电科院', 'dky', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1423', '300216', '千山药机', 'qsyj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1424', '300217', '东方电热', 'dfdr', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1425', '300218', '安利股份', 'algf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1426', '300219', '鸿利光电', 'hlgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1427', '300220', '金运激光', 'jyjg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1428', '300221', '银禧科技', 'yxkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1429', '300222', '科大智能', 'kdzn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1430', '300223', '北京君正', 'bjjz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1431', '300224', '正海磁材', 'zhcc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1432', '300225', '金力泰', 'jlt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1433', '300226', '上海钢联', 'shgl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1434', '300227', '光韵达', 'gyd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1435', '300228', '富瑞特装', 'frtz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1436', '300229', '拓尔思', 'tes', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1437', '300230', '永利带业', 'yldy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1438', '300231', '银信科技', 'yxkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1439', '300232', '洲明科技', 'zmkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1440', '300233', '金城医药', 'jcyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1441', '300234', '开尔新材', 'kexc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1442', '300235', '方直科技', 'fzkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1443', '300236', '上海新阳', 'shxy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1444', '300237', '美晨科技', 'mckj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1445', '300238', '冠昊生物', 'ghsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1446', '300239', '东宝生物', 'dbsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1447', '300240', '飞力达', 'fld', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1448', '300241', '瑞丰光电', 'rfgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1449', '300242', '明家科技', 'mjkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1450', '300243', '瑞丰高材', 'rfgc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1451', '300244', '迪安诊断', 'dazd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1452', '300245', '天玑科技', 'tjkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1453', '300246', '宝莱特', 'blt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1454', '300247', '桑乐金', 'slj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1455', '300248', '新开普', 'xkp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1456', '300249', '依米康', 'ymk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1457', '300250', '初灵信息', 'clxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1458', '300251', '光线传媒', 'gxcm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1459', '300252', '金信诺', 'jxn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1460', '300253', '卫宁软件', 'wnrj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1461', '300254', '仟源医药', 'qyyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1462', '300255', '常山药业', 'csyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1463', '300256', '星星科技', 'xxkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1464', '300257', '开山股份', 'ksgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1465', '300258', '精锻科技', 'jdkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1466', '300259', '新天科技', 'xtkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1467', '300260', '新莱应材', 'xlyc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1468', '300261', '雅本化学', 'ybhx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1469', '300262', '巴安水务', 'basw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1470', '300263', '隆华节能', 'lhjn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1471', '300264', '佳创视讯', 'jcsx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1472', '300265', '通光线缆', 'tgxl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1473', '300266', '兴源环境', 'xyhj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1474', '300267', '尔康制药', 'ekzy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1475', '300268', '万福生科', 'wfsk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1476', '300269', '联建光电', 'ljgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1477', '300270', '中威电子', 'zwdz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1478', '300271', '华宇软件', 'hyrj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1479', '300272', '开能环保', 'knhb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1480', '300273', '和佳股份', 'hjgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1481', '300274', '阳光电源', 'ygdy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1482', '300275', '梅安森', 'mas', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1483', '300276', '三丰智能', 'sfzn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1484', '300277', '海联讯', 'hlx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1485', '300278', '华昌达', 'hcd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1486', '300279', '和晶科技', 'hjkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1487', '300280', '南通锻压', 'ntdy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1488', '300281', '金明精机', 'jmjj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1489', '300282', '汇冠股份', 'hggf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1490', '300283', '温州宏丰', 'wzhf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1491', '300284', '苏交科', 'sjk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1492', '300285', '国瓷材料', 'gccl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1493', '300286', '安科瑞', 'akr', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1494', '300287', '飞利信', 'flx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1495', '300288', '朗玛信息', 'lmxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1496', '300289', '利德曼', 'ldm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1497', '300290', '荣科科技', 'rkkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1498', '300291', '华录百纳', 'hlbn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1499', '300292', '吴通通讯', 'wttx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1500', '300293', '蓝英装备', 'lyzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1501', '300294', '博雅生物', 'bysw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1502', '300295', '三六五网', 'slww', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1503', '300296', '利亚德', 'lyd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1504', '300297', '蓝盾股份', 'ldgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1505', '300298', '三诺生物', 'snsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1506', '300299', '富春通信', 'fctx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1507', '300300', '汉鼎股份', 'hdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1508', '300301', '长方照明', 'cfzm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1509', '300302', '同有科技', 'tykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1510', '300303', '聚飞光电', 'jfgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1511', '300304', '云意电气', 'yydq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1512', '300305', '裕兴股份', 'yxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1513', '300306', '远方光电', 'yfgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1514', '300307', '慈星股份', 'cxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1515', '300308', '中际装备', 'zjzb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1516', '300309', '吉艾科技', 'jakj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1517', '300310', '宜通世纪', 'ytsj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1518', '300311', '任子行', 'rzx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1519', '300312', '邦讯技术', 'bxjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1520', '300313', '天山生物', 'tssw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1521', '300314', '戴维医疗', 'dwyl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1522', '300315', '掌趣科技', 'zqkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1523', '300316', '晶盛机电', 'jsjd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1524', '300317', '珈伟股份', 'jwgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1525', '300318', '博晖创新', 'bhcx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1526', '300319', '麦捷科技', 'mjkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1527', '300320', '海达股份', 'hdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1528', '300321', '同大股份', 'tdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1529', '300322', '硕贝德', 'sbd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1530', '300323', '华灿光电', 'hcgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1531', '300324', '旋极信息', 'xjxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1532', '300325', '德威新材', 'dwxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1533', '300326', '凯利泰', 'klt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1534', '300327', '中颖电子', 'zydz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1535', '300328', '宜安科技', 'yakj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1536', '300329', '海伦钢琴', 'hlgq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1537', '300330', '华虹计通', 'hhjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1538', '300331', '苏大维格', 'sdwg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1539', '300332', '天壕节能', 'thjn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1540', '300333', '兆日科技', 'zrkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1541', '300334', '津膜科技', 'jmkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1542', '300335', '迪森股份', 'dsgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1543', '300336', '新文化', 'xwh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1544', '300337', '银邦股份', 'ybgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1545', '300338', '开元仪器', 'kyyq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1546', '300339', '润和软件', 'rhrj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1547', '300340', '科恒股份', 'khgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1548', '300341', '麦迪电气', 'mddq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1549', '300342', '天银机电', 'tyjd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1550', '300343', '联创节能', 'lcjn', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1551', '300344', '太空板业', 'tkby', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1552', '300345', '红宇新材', 'hyxc', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1553', '300346', '南大光电', 'ndgd', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1554', '300347', '泰格医药', 'tgyy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1555', '300348', '长亮科技', 'clkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1556', '300349', '金卡股份', 'jkgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1557', '300350', '华鹏飞', 'hpf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1558', '300351', '永贵电器', 'ygdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1559', '300352', '北信源', 'bxy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1560', '300353', '东土科技', 'dtkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1561', '300354', '东华测试', 'dhcs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1562', '300355', '蒙草抗旱', 'mckh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1563', '300356', '光一科技', 'gykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1564', '300357', '我武生物', 'wwsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1565', '300358', '楚天科技', 'ctkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1566', '300359', '全通教育', 'qtjy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1567', '300360', '炬华科技', 'jhkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1568', '300362', '天保重装', 'tbzz', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1569', '300363', '博腾股份', 'btgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1570', '300364', '中文在线', 'zwzx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1571', '300365', '恒华科技', 'hhkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1572', '300366', '创意信息', 'cyxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1573', '300367', '东方网力', 'dfwl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1574', '300368', '汇金股份', 'hjgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1575', '300369', '绿盟科技', 'lmkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1576', '300370', '安控科技', 'akkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1577', '300371', '汇中股份', 'hzgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1578', '300372', '欣泰电气', 'xtdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1579', '300373', '扬杰科技', 'yjkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1580', '300375', '鹏翎股份', 'plgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1581', '300376', '易事特', 'yst', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1582', '300377', '赢时胜', 'yss', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1583', '300378', '鼎捷软件', 'djrj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1584', '300379', '东方通', 'dft', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1585', '300380', '安硕信息', 'asxx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1586', '300381', '溢多利', 'ydl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1587', '300382', '斯莱克', 'slk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1588', '300383', '光环新网', 'ghxw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1589', '300384', '三联虹普', 'slhp', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1590', '300385', '雪浪环境', 'xlhj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1591', '300386', '飞天诚信', 'ftcx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1592', '300387', '富邦股份', 'fbgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1593', '300388', '国祯环保', 'gzhb', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1594', '300389', '艾比森', 'abs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1595', '300390', '天华超净', 'thcj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1596', '300391', '康跃科技', 'kykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1597', '300392', '腾信股份', 'txgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1598', '300393', '中来股份', 'zlgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1599', '300394', '天孚通信', 'tftx', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1600', '300395', '菲利华', 'flh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1601', '300396', '迪瑞医疗', 'dryl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1602', '300397', '天和防务', 'thfw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1603', '300398', '飞凯材料', 'fkcl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1604', '300399', '京天利', 'jtl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1605', '300400', '劲拓股份', 'jtgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1606', '300401', '花园生物', 'hysw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1607', '300402', '宝色股份', 'bsgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1608', '300403', '地尔汉宇', 'dehy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1609', '300405', '科隆精化', 'kljh', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1610', '300406', '九强生物', 'jqsw', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1611', '300407', '凯发电气', 'kfdq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1612', '300408', '三环集团', 'shjt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1613', '300409', '道氏技术', 'dsjs', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1614', '300410', '正业科技', 'zykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1615', '300411', '金盾股份', 'jdgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1616', '300412', '迦南科技', 'jnkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1617', '300413', '快乐购', 'klg', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1618', '300415', '伊之密', 'yzm', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1619', '300416', '苏试试验', 'sssy', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1620', '300417', '南华仪器', 'nhyq', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1621', '300418', '昆仑万维', 'klww', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1622', '300419', '浩丰科技', 'hfkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1623', '300420', '五洋科技', 'wykj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1624', '300421', '力星股份', 'lxgf', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1625', '300422', '博世科', 'bsk', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1626', '300423', '鲁亿通', 'lyt', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1627', '300425', '环能科技', 'hnkj', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1628', '300426', '唐德影视', 'tdys', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1629', '300427', '红相电力', 'hxdl', '1', '0', '0');
INSERT INTO `rm_codes` VALUES ('1630', '200011', '深物业B', 'swyB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1631', '200012', '南玻B', 'nbB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1632', '200016', '深康佳B', 'skjB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1633', '200017', '深中华B', 'szhB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1634', '200018', '中冠B', 'zgB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1635', '200019', '深深宝B', 'ssbB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1636', '200020', '深华发B', 'shfB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1637', '200022', '深赤湾B', 'scwB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1638', '200024', '招商局B', 'zsjB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1639', '200025', '特力B', 'tlB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1640', '200026', '飞亚达B', 'fydB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1641', '200028', '一致B', 'yzB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1642', '200029', '深深房B', 'ssfB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1643', '200030', '富奥B', 'faB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1644', '200037', '深南电B', 'sndB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1645', '200045', '深纺织B', 'sfzB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1646', '200053', '深基地B', 'sjdB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1647', '200054', '建摩B', 'jmB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1648', '200055', '方大B', 'fdB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1649', '200056', '深国商B', 'sgsB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1650', '200058', '深赛格B', 'ssgB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1651', '200152', '山航B', 'shB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1652', '200160', '南江B', 'njB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1653', '200168', '雷伊B', 'lyB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1654', '200413', '东旭B', 'dxB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1655', '200418', '小天鹅B', 'xteB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1656', '200429', '粤高速B', 'ygsB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1657', '200468', '宁通信B', 'ntxB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1658', '200488', '晨鸣B', 'cmB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1659', '200505', '珠江B', 'zjB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1660', '200512', '闽灿坤B', 'mckB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1661', '200521', '皖美菱B', 'wmlB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1662', '200530', '大冷B', 'dlB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1663', '200539', '粤电力B', 'ydlB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1664', '200541', '粤照明B', 'yzmB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1665', '200550', '江铃B', 'jlB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1666', '200553', '沙隆达B', 'sldB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1667', '200570', '苏常柴B', 'sccB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1668', '200581', '苏威孚B', 'swfB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1669', '200596', '古井贡B', 'gjgB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1670', '200613', '大东海B', 'ddhB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1671', '200625', '长安B', 'caB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1672', '200706', '瓦轴B', 'wzB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1673', '200725', '京东方B', 'jdfB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1674', '200726', '鲁泰B', 'ltB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1675', '200761', '本钢板B', 'bgbB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1676', '200770', '*ST武锅B', '*STwgB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1677', '200771', '杭汽轮B', 'hqlB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1678', '200869', '张裕B', 'zyB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1679', '200986', '粤华包B', 'yhbB', '2', '0', '0');
INSERT INTO `rm_codes` VALUES ('1680', '200992', '中鲁B', 'zlB', '2', '0', '0');

-- -----------------------------
-- Table structure for `rm_collect`
-- -----------------------------
DROP TABLE IF EXISTS `rm_collect`;
CREATE TABLE `rm_collect` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `topic_id` int(11) unsigned NOT NULL COMMENT '主题ID',
  `author_id` int(11) unsigned NOT NULL COMMENT '作者ID',
  `author_nick` char(50) NOT NULL COMMENT '作者昵称',
  `title` char(100) NOT NULL COMMENT '标题',
  `thumb` char(200) NOT NULL COMMENT '缩略图',
  `gold_price` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '金币价',
  `user_id` int(11) unsigned NOT NULL COMMENT '用户ID',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `add_time` int(11) unsigned NOT NULL COMMENT '加入时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='收藏表';

-- -----------------------------
-- Records of `rm_collect`
-- -----------------------------
INSERT INTO `rm_collect` VALUES ('8', '8', '5', 'dys', '测试主题5', '/Uploads/Picture/150303/54f598466b6f7.jpg', '0', '1', '0', '1426601933');
INSERT INTO `rm_collect` VALUES ('3', '12', '6', 'dysecho', '测试', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', '8', '6', '0', '1426125707');
INSERT INTO `rm_collect` VALUES ('5', '3', '1', 'ninstein', 'fdfdsfs', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', '0', '7', '0', '1426408119');
INSERT INTO `rm_collect` VALUES ('6', '3', '1', 'ninstein', 'fdfdsfs', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', '0', '8', '0', '1426433111');
INSERT INTO `rm_collect` VALUES ('7', '8', '5', 'dys', '测试主题5', '/Uploads/Picture/150303/54f598466b6f7.jpg', '0', '5', '0', '1426519533');

-- -----------------------------
-- Table structure for `rm_config`
-- -----------------------------
DROP TABLE IF EXISTS `rm_config`;
CREATE TABLE `rm_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `rm_config`
-- -----------------------------
INSERT INTO `rm_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', '金融炼金术', '0');
INSERT INTO `rm_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', '金融炼金术', '1');
INSERT INTO `rm_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', '金融炼金术', '8');
INSERT INTO `rm_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `rm_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '2');
INSERT INTO `rm_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '9');
INSERT INTO `rm_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表推荐\r\n2:频道推荐\r\n4:首页推荐', '3');
INSERT INTO `rm_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '4');
INSERT INTO `rm_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'default_color', '10');
INSERT INTO `rm_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统', '4');
INSERT INTO `rm_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '6');
INSERT INTO `rm_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '8');
INSERT INTO `rm_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '1');
INSERT INTO `rm_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '2');
INSERT INTO `rm_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '10');
INSERT INTO `rm_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `rm_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '3');
INSERT INTO `rm_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `rm_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `rm_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `rm_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `rm_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '11');
INSERT INTO `rm_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '0');
INSERT INTO `rm_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '0');
INSERT INTO `rm_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '10', '0');
INSERT INTO `rm_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `rm_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '1');

-- -----------------------------
-- Table structure for `rm_document`
-- -----------------------------
DROP TABLE IF EXISTS `rm_document`;
CREATE TABLE `rm_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `group_id` smallint(3) unsigned NOT NULL COMMENT '所属分组',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `rm_document`
-- -----------------------------
INSERT INTO `rm_document` VALUES ('1', '1', '', 'OneThink1.1开发版发布', '2', '0', '期待已久的OneThink最新版发布', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '29', '0', '0', '0', '1406001413', '1406001413', '1');

-- -----------------------------
-- Table structure for `rm_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `rm_document_article`;
CREATE TABLE `rm_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `rm_document_article`
-- -----------------------------
INSERT INTO `rm_document_article` VALUES ('1', '0', '<h1>\r\n	OneThink1.1开发版发布&nbsp;\r\n</h1>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>OneThink是一个开源的内容管理框架，基于最新的ThinkPHP3.2版本开发，提供更方便、更安全的WEB应用开发体验，采用了全新的架构设计和命名空间机制，融合了模块化、驱动化和插件化的设计理念于一体，开启了国内WEB应用傻瓜式开发的新潮流。&nbsp;</strong> \r\n</p>\r\n<h2>\r\n	主要特性：\r\n</h2>\r\n<p>\r\n	1. 基于ThinkPHP最新3.2版本。\r\n</p>\r\n<p>\r\n	2. 模块化：全新的架构和模块化的开发机制，便于灵活扩展和二次开发。&nbsp;\r\n</p>\r\n<p>\r\n	3. 文档模型/分类体系：通过和文档模型绑定，以及不同的文档类型，不同分类可以实现差异化的功能，轻松实现诸如资讯、下载、讨论和图片等功能。\r\n</p>\r\n<p>\r\n	4. 开源免费：OneThink遵循Apache2开源协议,免费提供使用。&nbsp;\r\n</p>\r\n<p>\r\n	5. 用户行为：支持自定义用户行为，可以对单个用户或者群体用户的行为进行记录及分享，为您的运营决策提供有效参考数据。\r\n</p>\r\n<p>\r\n	6. 云端部署：通过驱动的方式可以轻松支持平台的部署，让您的网站无缝迁移，内置已经支持SAE和BAE3.0。\r\n</p>\r\n<p>\r\n	7. 云服务支持：即将启动支持云存储、云安全、云过滤和云统计等服务，更多贴心的服务让您的网站更安心。\r\n</p>\r\n<p>\r\n	8. 安全稳健：提供稳健的安全策略，包括备份恢复、容错、防止恶意攻击登录，网页防篡改等多项安全管理功能，保证系统安全，可靠、稳定的运行。&nbsp;\r\n</p>\r\n<p>\r\n	9. 应用仓库：官方应用仓库拥有大量来自第三方插件和应用模块、模板主题，有众多来自开源社区的贡献，让您的网站“One”美无缺。&nbsp;\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>&nbsp;OneThink集成了一个完善的后台管理体系和前台模板标签系统，让你轻松管理数据和进行前台网站的标签式开发。&nbsp;</strong> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<h2>\r\n	后台主要功能：\r\n</h2>\r\n<p>\r\n	1. 用户Passport系统\r\n</p>\r\n<p>\r\n	2. 配置管理系统&nbsp;\r\n</p>\r\n<p>\r\n	3. 权限控制系统\r\n</p>\r\n<p>\r\n	4. 后台建模系统&nbsp;\r\n</p>\r\n<p>\r\n	5. 多级分类系统&nbsp;\r\n</p>\r\n<p>\r\n	6. 用户行为系统&nbsp;\r\n</p>\r\n<p>\r\n	7. 钩子和插件系统\r\n</p>\r\n<p>\r\n	8. 系统日志系统&nbsp;\r\n</p>\r\n<p>\r\n	9. 数据备份和还原\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	&nbsp;[ 官方下载：&nbsp;<a href=\"http://www.onethink.cn/download.html\" target=\"_blank\">http://www.onethink.cn/download.html</a>&nbsp;&nbsp;开发手册：<a href=\"http://document.onethink.cn/\" target=\"_blank\">http://document.onethink.cn/</a>&nbsp;]&nbsp;\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>OneThink开发团队 2013~2014</strong> \r\n</p>', '', '0');

-- -----------------------------
-- Table structure for `rm_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `rm_document_download`;
CREATE TABLE `rm_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `rm_file`
-- -----------------------------
DROP TABLE IF EXISTS `rm_file`;
CREATE TABLE `rm_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '远程地址',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件表';


-- -----------------------------
-- Table structure for `rm_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `rm_hooks`;
CREATE TABLE `rm_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `rm_hooks`
-- -----------------------------
INSERT INTO `rm_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '', '1');
INSERT INTO `rm_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop', '1');
INSERT INTO `rm_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', 'Attachment', '1');
INSERT INTO `rm_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment', '1');
INSERT INTO `rm_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '', '1');
INSERT INTO `rm_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment', '1');
INSERT INTO `rm_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor', '1');
INSERT INTO `rm_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin', '1');
INSERT INTO `rm_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam', '1');
INSERT INTO `rm_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor', '1');
INSERT INTO `rm_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '', '1');

-- -----------------------------
-- Table structure for `rm_member`
-- -----------------------------
DROP TABLE IF EXISTS `rm_member`;
CREATE TABLE `rm_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  PRIMARY KEY (`uid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `rm_member`
-- -----------------------------
INSERT INTO `rm_member` VALUES ('1', 'ninstein', '0', '0000-00-00', '', '110', '31', '0', '1419606772', '1928979522', '1427718059', '1');
INSERT INTO `rm_member` VALUES ('2', '36020', '0', '0000-00-00', '', '10', '1', '0', '0', '3732974641', '1419607037', '1');
INSERT INTO `rm_member` VALUES ('3', '122020131', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO `rm_member` VALUES ('4', '179814878', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO `rm_member` VALUES ('6', 'dysecho', '0', '0000-00-00', '', '30', '17', '1919964149', '1425286760', '3659428868', '1426125308', '1');
INSERT INTO `rm_member` VALUES ('5', 'dys', '0', '0000-00-00', '', '60', '14', '3659428867', '1425289298', '3659428868', '1426556824', '1');
INSERT INTO `rm_member` VALUES ('7', 'ninstein1', '0', '0000-00-00', '', '10', '1', '1928976873', '1426408101', '1928976873', '1426408101', '1');
INSERT INTO `rm_member` VALUES ('8', 'bparadise', '0', '0000-00-00', '', '10', '3', '1697110737', '1426432998', '3059547418', '1426502553', '1');

-- -----------------------------
-- Table structure for `rm_menu`
-- -----------------------------
DROP TABLE IF EXISTS `rm_menu`;
CREATE TABLE `rm_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `rm_menu`
-- -----------------------------
INSERT INTO `rm_menu` VALUES ('1', '首页', '0', '1', 'Index/index', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('2', '内容', '0', '2', 'Article/index', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('3', '文档列表', '2', '0', 'article/index', '1', '', '内容', '0', '1');
INSERT INTO `rm_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('13', '回收站', '2', '0', 'article/recycle', '1', '', '内容', '0', '1');
INSERT INTO `rm_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('16', '用户', '0', '3', 'User/index', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('17', '用户信息', '16', '0', 'User/index', '0', '', '用户管理', '0', '1');
INSERT INTO `rm_menu` VALUES ('18', '新增用户', '17', '0', 'User/add', '0', '添加新用户', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('19', '用户行为', '16', '0', 'User/action', '0', '', '行为管理', '0', '1');
INSERT INTO `rm_menu` VALUES ('20', '新增用户行为', '19', '0', 'User/addaction', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('21', '编辑用户行为', '19', '0', 'User/editaction', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('22', '保存用户行为', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('23', '变更行为状态', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('24', '禁用会员', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('25', '启用会员', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('26', '删除会员', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('27', '权限管理', '16', '0', 'AuthManager/index', '0', '', '用户管理', '0', '1');
INSERT INTO `rm_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('30', '恢复', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('33', '保存用户组', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('43', '扩展', '0', '7', 'Addons/index', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('44', '插件管理', '43', '1', 'Addons/index', '0', '', '扩展', '0', '1');
INSERT INTO `rm_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('46', '检测创建', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('48', '快速生成插件', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('57', '钩子管理', '43', '2', 'Addons/hooks', '0', '', '扩展', '0', '1');
INSERT INTO `rm_menu` VALUES ('58', '模型管理', '68', '3', 'Model/index', '0', '', '系统设置', '0', '1');
INSERT INTO `rm_menu` VALUES ('59', '新增', '58', '0', 'model/add', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('61', '改变状态', '58', '0', 'model/setStatus', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('63', '属性管理', '68', '0', 'Attribute/index', '1', '网站属性配置。', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('66', '改变状态', '63', '0', 'Attribute/setStatus', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('68', '系统', '0', '4', 'Config/group', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('69', '网站设置', '68', '1', 'Config/group', '0', '', '系统设置', '0', '1');
INSERT INTO `rm_menu` VALUES ('70', '配置管理', '68', '4', 'Config/index', '0', '', '系统设置', '0', '1');
INSERT INTO `rm_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('75', '菜单管理', '68', '5', 'Menu/index', '0', '', '系统设置', '0', '1');
INSERT INTO `rm_menu` VALUES ('76', '导航管理', '68', '6', 'Channel/index', '0', '', '系统设置', '0', '1');
INSERT INTO `rm_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('80', '分类管理', '68', '2', 'Category/index', '0', '', '系统设置', '0', '1');
INSERT INTO `rm_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('84', '移动', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('85', '合并', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('86', '备份数据库', '68', '0', 'Database/index?type=export', '0', '', '数据备份', '0', '1');
INSERT INTO `rm_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据库', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('88', '优化表', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('89', '修复表', '86', '0', 'Database/repair', '0', '修复数据表', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('90', '还原数据库', '68', '0', 'Database/index?type=import', '0', '', '数据备份', '0', '1');
INSERT INTO `rm_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢复', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('93', '其他', '0', '5', 'other', '1', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '0', '', '系统设置', '0', '1');
INSERT INTO `rm_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('106', '行为日志', '16', '0', 'Action/actionlog', '0', '', '行为管理', '0', '1');
INSERT INTO `rm_menu` VALUES ('108', '修改密码', '16', '0', 'User/updatePassword', '1', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('109', '修改昵称', '16', '0', 'User/updateNickname', '1', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '1', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '1', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '1', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('118', '文档排序', '3', '0', 'Article/sort', '1', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '1', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '1', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('122', '数据列表', '58', '0', 'think/lists', '1', '', '', '0', '1');
INSERT INTO `rm_menu` VALUES ('123', '审核列表', '3', '0', 'Article/examine', '1', '', '', '0', '1');

-- -----------------------------
-- Table structure for `rm_model`
-- -----------------------------
DROP TABLE IF EXISTS `rm_model`;
CREATE TABLE `rm_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text COMMENT '属性列表（表的字段）',
  `attribute_alias` varchar(255) NOT NULL DEFAULT '' COMMENT '属性别名定义',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `rm_model`
-- -----------------------------
INSERT INTO `rm_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntitle:标题:[EDIT]\r\ntype:类型\r\nupdate_time:最后更新\r\nstatus:状态\r\nview:浏览\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '0', '', '', '1383891233', '1384507827', '1', 'MyISAM');
INSERT INTO `rm_model` VALUES ('2', 'article', '文章', '1', '', '1', '{\"1\":[\"3\",\"24\",\"2\",\"5\"],\"2\":[\"9\",\"13\",\"19\",\"10\",\"12\",\"16\",\"17\",\"26\",\"20\",\"14\",\"11\",\"25\"]}', '1:基础,2:扩展', '', '', '', '', '', '', '0', '', '', '1383891243', '1387260622', '1', 'MyISAM');
INSERT INTO `rm_model` VALUES ('3', 'download', '下载', '1', '', '1', '{\"1\":[\"3\",\"28\",\"30\",\"32\",\"2\",\"5\",\"31\"],\"2\":[\"13\",\"10\",\"27\",\"9\",\"12\",\"16\",\"17\",\"19\",\"11\",\"20\",\"14\",\"29\"]}', '1:基础,2:扩展', '', '', '', '', '', '', '0', '', '', '1383891252', '1387260449', '1', 'MyISAM');

-- -----------------------------
-- Table structure for `rm_picture`
-- -----------------------------
DROP TABLE IF EXISTS `rm_picture`;
CREATE TABLE `rm_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `rm_picture`
-- -----------------------------
INSERT INTO `rm_picture` VALUES ('1', '/Uploads/Picture/2015-03-03/54f493a3b71b3.png', '', '8b822aa6e77483be125992a62b7a8748', '9ae50ef3fa6408d8482269cf1196bd85b3a02b51', '1', '1425314721');
INSERT INTO `rm_picture` VALUES ('2', '/Uploads/Picture/2015-03-03/54f515b4bb89a.png', '', 'f7aec314e1916bf12a46caf55ea947ac', '0b5fe01203ea843d9ce57ec076deba6686b972fc', '1', '1425348020');
INSERT INTO `rm_picture` VALUES ('3', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', '', '89cf395811c0f32143129de83577e020', 'e1ebb806a11aa36c8c1168e8245af26c85acf145', '1', '1425348351');
INSERT INTO `rm_picture` VALUES ('4', '/Uploads/Picture/150303/54f51cee81e54.png', '', '451194f4512f2c51883458101497dfa7', '671b1c697ee5722995eed047ef849002f3eea794', '1', '1425349870');
INSERT INTO `rm_picture` VALUES ('5', '/Uploads/Picture/150303/54f548582a7b8.gif', '', '431b4027106492f2e7ac73b8c4f8a5ea', 'a79ba7ac72e857cefede54eb695564277ec3238e', '1', '1425360982');
INSERT INTO `rm_picture` VALUES ('6', '/Uploads/Picture/150303/54f55081d40b6.jpg', '', '385420e12bacc41621a348922f6213aa', '64a293198b44b3fddc7f926af80d901dc0dd7bed', '1', '1425363073');
INSERT INTO `rm_picture` VALUES ('7', '/Uploads/Picture/150303/54f58122a7efa.png', '', '8d5e979068b7b6433a6b3fa6f33957bb', '534f10cdada48b8c0afdcfa09193b679256beaf0', '1', '1425375522');
INSERT INTO `rm_picture` VALUES ('8', '/Uploads/Picture/150303/54f598466b6f7.jpg', '', '5d6d813e7f20583195a8e3668e125a18', '484d5856353ebabb99a02268242de75efbf6092e', '1', '1425381444');
INSERT INTO `rm_picture` VALUES ('9', '/Uploads/Picture/150305/54f836e5ba70b.jpg', '', '027c0d6d3e052fa9be89b65250a9482a', 'c8370644fcd32fe21b473981702bdb0b8cd7f03c', '1', '1425553125');
INSERT INTO `rm_picture` VALUES ('10', '/Uploads/Picture/150316/5506b4cc91c72.png', '', '5e6e272ed485d0757dbf184b440d5ade', '6de5e9ad06d0a2d696c79c81a28cde3ed27f0a00', '1', '1426502859');
INSERT INTO `rm_picture` VALUES ('11', '/Uploads/Picture/150316/5506b4e9a2daa.png', '', '99df14dd6060a227fe24e1d605f43522', '9ba5964bbd14f804437130b803661ca6bbc1c7ed', '1', '1426502889');
INSERT INTO `rm_picture` VALUES ('12', '/Uploads/Picture/150316/5506b4f5a6ded.png', '', '62f376b8a2770a85d1609e7561b22985', '6635d02231913ce9e74960b0002537fae080d7b6', '1', '1426502898');

-- -----------------------------
-- Table structure for `rm_topic`
-- -----------------------------
DROP TABLE IF EXISTS `rm_topic`;
CREATE TABLE `rm_topic` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` char(100) NOT NULL COMMENT '标题',
  `thumb` char(200) NOT NULL COMMENT '缩略图',
  `gold_price` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '金币价',
  `description` text NOT NULL COMMENT '描述',
  `parameter` varchar(1024) NOT NULL COMMENT '参数',
  `stocks` varchar(2048) NOT NULL COMMENT '股票配置',
  `pictures` varchar(1024) NOT NULL COMMENT '图片',
  `remark` varchar(1024) NOT NULL COMMENT '备注',
  `author_id` int(11) unsigned NOT NULL COMMENT '作者',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `create_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `rm_topic`
-- -----------------------------
INSERT INTO `rm_topic` VALUES ('1', '测试主题', 'http://120.27.42.165/Public/V1/image/topic_detail_1.png', '0', '测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题测试主题\n测试主题测试主题测试主题测试主题\n测试主题', '股票数目：5-20只\n持仓时间：2个月以上\n风险评估：稳健\n更新频率：视市场条件而定\n建议配置资金范围：10万-500万', '', '', '', '1', '99', '1425918911', '1425570324');
INSERT INTO `rm_topic` VALUES ('2', 'devin 测试', '/Uploads/Picture/150303/54f598466b6f7.jpg', '0', '咚咚锵锵  测试了', '股票数目：5-20只\n持仓时间：2个月以上\n风险评估：稳健\n更新频率：视市场条件而定\n建议配置资金范围：10万-500万', '000400~50.0|002500~50.0', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg|/Uploads/Picture/150303/54f55081d40b6.jpg', '', '1', '99', '1426007592', '1425646512');
INSERT INTO `rm_topic` VALUES ('3', 'fdfdsfs', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', '0', 'fsfsfdsfsddfdsfs', '股票数目：5-20只\n持仓时间：2个月以上\n风险评估：稳健\n更新频率：视市场条件而定\n建议配置资金范围：10万-500万', '200160~50.0|000788~50.0', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg|/Uploads/Picture/150303/54f55081d40b6.jpg', '', '1', '0', '1425647388', '1425647388');
INSERT INTO `rm_topic` VALUES ('4', '测试主题1', '/Uploads/Picture/150303/54f598466b6f7.jpg', '0', '', '股票数目：5-20只\n持仓时间：2个月以上\n风险评估：稳健\n更新频率：视市场条件而定\n建议配置资金范围：10万-500万', 'undefined~undefined', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg|/Uploads/Picture/150303/54f55081d40b6.jpg', '', '5', '99', '1426001952', '1425647544');
INSERT INTO `rm_topic` VALUES ('5', '测试主题2', '/Uploads/Picture/150303/54f598466b6f7.jpg', '0', '', '股票数目：5-20只\n持仓时间：2个月以上\n风险评估：稳健\n更新频率：视市场条件而定\n建议配置资金范围：10万-500万', 'undefined~undefined', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg|/Uploads/Picture/150303/54f55081d40b6.jpg', '', '1', '0', '1425647561', '1425647561');
INSERT INTO `rm_topic` VALUES ('6', '测试主题3', '/Uploads/Picture/150303/54f598466b6f7.jpg', '0', '', '股票数目：5-20只\n持仓时间：2个月以上\n风险评估：稳健\n更新频率：视市场条件而定\n建议配置资金范围：10万-500万', 'undefined~undefined', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg|/Uploads/Picture/150303/54f55081d40b6.jpg', '', '1', '0', '1425647678', '1425647678');
INSERT INTO `rm_topic` VALUES ('7', '测试主题4', '/Uploads/Picture/150303/54f598466b6f7.jpg', '0', '', '股票数目：5-20只\n持仓时间：2个月以上\n风险评估：稳健\n更新频率：视市场条件而定\n建议配置资金范围：10万-500万', 'undefined~undefined', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg|/Uploads/Picture/150303/54f55081d40b6.jpg', '', '5', '99', '1426003375', '1425647710');
INSERT INTO `rm_topic` VALUES ('8', '测试主题5', '/Uploads/Picture/150303/54f598466b6f7.jpg', '0', '', '股票数目：5-20只\n持仓时间：2个月以上\n风险评估：稳健\n更新频率：视市场条件而定\n建议配置资金范围：10万-500万', 'undefined~undefined', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg|/Uploads/Picture/150303/54f55081d40b6.jpg', '', '5', '0', '1425647725', '1425647725');
INSERT INTO `rm_topic` VALUES ('9', '测试主题6', '/Uploads/Picture/150303/54f598466b6f7.jpg', '0', '', '股票数目：5-20只\n持仓时间：2个月以上\n风险评估：稳健\n更新频率：视市场条件而定\n建议配置资金范围：10万-500万', 'undefined~undefined', '', '', '1', '0', '1425648016', '1425648016');
INSERT INTO `rm_topic` VALUES ('10', '解决', '/Uploads/Picture/150303/54f55081d40b6.jpg', '0', 'ui嘻嘻', '股票数目：5-20只\n持仓时间：2个月以上\n风险评估：稳健\n更新频率：视市场条件而定\n建议配置资金范围：10万-500万', '000880~50.0|000609~50.0', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', 'D大调', '1', '0', '1425651230', '1425651230');
INSERT INTO `rm_topic` VALUES ('11', 'devini', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', '0', 'devini  test', '对方答复的', '002400~50.0|002500~50.0', '/Uploads/Picture/150303/54f55081d40b6.jpg|/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', 'xxx xxdf d', '5', '99', '1426002402', '1426000436');
INSERT INTO `rm_topic` VALUES ('12', '测试', '/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', '8', '测试用的打法上发生', '1213234324', '000400~50.0|002500~50.0', '/Uploads/Picture/150303/54f55081d40b6.jpg|/Uploads/Picture/2015-03-03/54f516ffb895e.jpg', '的方式发生的', '6', '0', '1426125388', '1426125388');

-- -----------------------------
-- Table structure for `rm_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `rm_ucenter_admin`;
CREATE TABLE `rm_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `rm_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `rm_ucenter_app`;
CREATE TABLE `rm_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL DEFAULT '' COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL DEFAULT '' COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `rm_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `rm_ucenter_member`;
CREATE TABLE `rm_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `rm_ucenter_member`
-- -----------------------------
INSERT INTO `rm_ucenter_member` VALUES ('1', 'ninstein', '7b0e691a0f75073817665628cb9bc1ef', 'ninstein@qq.com', '', '1419606772', '3732974883', '1427718059', '1928979522', '1419606772', '1');
INSERT INTO `rm_ucenter_member` VALUES ('2', '36020', '5728aeeb02492fa277369480847a310f', '36020@qq.com', '', '1419606866', '3732975321', '1419607037', '3732974641', '1419606866', '1');
INSERT INTO `rm_ucenter_member` VALUES ('3', '122020131', 'b08bc415c09a19cb3b0de7faff7a78cc', '122020131@qq.com', '', '1419606891', '3732974883', '0', '0', '1419606891', '1');
INSERT INTO `rm_ucenter_member` VALUES ('4', '179814878', '99a39428ffb9105fb266e0967b4d4bcb', '179814878@qq.com', '', '1419606909', '3732975321', '0', '0', '1419606909', '1');
INSERT INTO `rm_ucenter_member` VALUES ('5', 'dys', 'a655197a3a4aaedd7d67fa4470cd344e', 'egaga@sina.com', '15810197762', '1425275271', '3659428868', '1426556824', '3659428868', '1425275271', '1');
INSERT INTO `rm_ucenter_member` VALUES ('6', 'dysecho', '1ea3eac5e84b1bf44d0b2225ca511e5b', 'egaga1@sina.com', '15810197761', '1425285849', '3659428867', '1426125308', '3659428868', '1425285849', '1');
INSERT INTO `rm_ucenter_member` VALUES ('7', 'ninstein1', '0090272abe690a2cdd3249f3df7d1b07', 'ninstein@sohu.com', '13222221111', '1426408086', '1928977780', '1426408101', '1928976873', '1426408086', '1');
INSERT INTO `rm_ucenter_member` VALUES ('8', 'bparadise', 'f99add0002ce74bb730140aace8ac0ec', '44612156@qq.com', '13691381009', '1426432948', '1697110737', '1426502553', '3059547418', '1426432948', '1');

-- -----------------------------
-- Table structure for `rm_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `rm_ucenter_setting`;
CREATE TABLE `rm_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `rm_url`
-- -----------------------------
DROP TABLE IF EXISTS `rm_url`;
CREATE TABLE `rm_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `rm_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `rm_userdata`;
CREATE TABLE `rm_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

